bla = process.cwd()

const PORT = process.env.PORT || 4515
var { criador, bannerName, bannerOn } = require('./config.json')
var fs = require('fs')
var axios = require('axios')
var mumaker = require('mumaker')
var jpeg = require('jpeg-js')
//const publicIp = require('public-ip'); 
//const canvasx = require('canvas')
const { GOOGLE_IMG_SCRAP , GOOGLE_QUERY } = require('google-img-scrap');
const { search } = require('yt-search'); 
var multer = require('multer')
var TinyUrl = require('tinyurl');
var BitlyClient = require('bitly').BitlyClient
var express = require('express')
var cron = require('node-cron');
var request = require('request'); 
var cheerio = require('cheerio');
var fetch = require('node-fetch')
var FormData = require('form-data')
var { igstory} = require('./lib/scrape.js');
var { fromBuffer } = require('file-type')
var gerarnick = require('./lib/gerarnick.js')
const mediafire = require('./modulos-api/mediafire.js');
var buffer = require('./lib/upload.js')
var { exec } = require('child_process');
var { Maker } = require('imagemaker.js')
var { pinterestVideoV2 } = require('./modulos-api/pinterest.js') 
var TikTokScraper = require('tiktok-scraper');
var download = require('@phaticusthiccy/open-apis')
var thiccysapi = require('textmaker-thiccy');
var { pinterest, getBuffer , fetchJson , ping } = require('./lib/funcoes.js') 
var trans = require('@vitalets/google-translate-api')
const cors = require('cors')
const { wikimedia } = require("./modulos-api/ScrapersNS/wikimedia.js")
var { color } = require('./lib/color.js')
const { fbdown } = require("./lib/facebook.js")
const { gis } = require('./lib/gimage')
var { nerding, gpwhatsapp, apkmody, pornhubsrc, uptodown, soundl, playstore, manga, anime, hentaistube, pornogratis, filme, wattpad, ssweb } = require('./modulos-api/scraper.js')
var { pensadorSearch, wallpaper2 } = require('./modulos-api/scrapperlinda.js')
var { tiktok2, FacebookMp4 } = require('./modulos-api/teste.js')
var { PlayStoreSearch, MercadoLivreSearch, AmazonSearch, AmericanasSearch, SubmarinoSearch, Horoscopo } = require('./lib/scraper/pesquisas.js')
//const { Classic, Dynamic } = require('musicard');
//const { musicCard } = require('musicard-quartz');
var { kwai } = require('./modulos-api/kwai.js')
var { InArtificial, CorretorOpenAi } = require('./modulos-api/scrapper-vip.js')
var { getVideosPlaylist } = require('./modulos-api/playlist.js')
var { G1, Poder360, JovemPan, Uol, CNNBrasil, Estadao } = require('./lib/scraper/noticias.js')
var { memesDroid } = require('./lib/scraper/aleacrapper.js')
var { ringtone } = require('./lib/scraper/ringtone.js')
var { LetradaMusica } = require('./modulos-api/letraMusic.js')
const { randomGrupos } = require('./modulos-api/groups-random.js');
const { EncoderApi } = require('./modulos-api/functions.js');
var { mercadoLivreSearch2 } = require('./modulos-api/scrapperlinda.js')
const { igdl } = require('./modulos-api/igdl.js') 
const cfonts = require("cfonts")
const { pornhub } = require('./modulos-api/pornhub.js');
const { xnxxsearch } = require('./modulos-api/xnxx.js');
const yts = require('yt-search');   
var { ytSearch } = require('./lib/yt.js')
//const { youtubedl } = require('./node_modules/@bochilteam/scraper-sosmed/lib/cjs/src/youtube.js');
const { RequestsAdd } = require(bla + '/modulos-api/totalreq.js');   
//const ipPublico = await publicIp.v4().catch(() => 'Não disponível');
var msgerro = 'Erro Ocorrido Contate O suporte!'


 
var apicuttly = ['2038c1a7754b408aa8f9055282638c00e668e','4786cc6a0f19de9c67ea6a4282c494323c932','89d73b3a07209177d0251e30d49d66bd669ac','e841147455d0fdfbf50f74aefe63b6728adc0','27f3aa3f45cb4460bcbac69b782ca470a4570','31a8df09d5a9d8d009790df0b5642e3d76919','09b4e764ff07b10eac1682e71aaf95a78f358','75fe576ce040b619176af22f5a718b2f574f5','e24ee36f9c1519c0a779667a5182a31fb7ccf','903869065d29e23455ddca922071f4bbeb133']
var apibitly = ['2243940c230ad0d748059aee58ddf126b65fd8e7','6cfc18e9bfa554714fadc10a1f6aff7555642348','c71b6658a1d271ddaf2a5077de3dcb9d67f68025','cddbceccdc2f1c9d11e4cdd0d2b1d1078e447c43','7915c671fbd90eca96310e5c9442d761225a1080','e5dee46eb2d69fc9f4b0057266226a52a3555356','f09ab8db9cf778b37a1cf8bc406eee5063816dec','964080579f959c0cc3226b4b2053cd6520bb60ad','a4f429289bf8bf6291be4b1661df57dde5066525','3d48e2601f25800f375ba388c30266aad54544ae','4854cb9fbad67724a2ef9c27a9d1a4e9ded62faa','d375cf1fafb3dc17e711870524ef4589995c4f69','43f58e789d57247b2cf285d7d24ab755ba383a28','971f6c6c2efe6cb5d278b4164acef11c5f21b637','ae128b3094c96bf5fd1a349e7ac03113e21d82c9','e65f2948f584ffd4c568bf248705eee2714abdd2','08425cf957368db9136484145aa6771e1171e232','dc4bec42a64749b0f23f1a8f525a69184227e301','0f9eb729a7a08ff5e73fe1860c6dc587cc523035','037c5017712c8f5f154ebbe6f91db1f82793c375']
var randomapicuttly = apicuttly[Math.floor(Math.random() * apicuttly.length)]

const router = express.Router();
const uuid = require('uuid').v4;
const path = require("path");
const { dirname } = require('path');
var __dirname = dirname(__filename);

var key = JSON.parse(fs.readFileSync("./lib/secret/keys.json"));
const users = JSON.parse(fs.readFileSync("./lib/secret/usuarios.json"));

async function listkeys(apikey, req) {
var i4 = key.map(i => i?.apikey)?.indexOf(apikey)
if(i4 >= 0) {
key[i4].request -= 2;
fs.writeFileSync("./lib/secret/keys.json", JSON.stringify(key, null, 2));
await RequestsAdd(); 
var IP = req.headers['x-real-ip'] || req.connection.remoteAddress || 0;
var i3 = users.map(i => i.key).indexOf(apikey);
if(i3 < 0 && !users.map(i => i.IP).includes(IP?.split(":")[3])){
users.push({key: apikey, IP: [IP?.split(":")[3]]})
fs.writeFileSync("./lib/secret/usuarios.json", JSON.stringify(users, null, 2));
} else if(i3 >= 0 && !users[i3]?.IP.includes(IP?.split(":")[3])) {
users[i3].IP.push(IP?.split(":")[3])
fs.writeFileSync("./lib/secret/usuarios.json", JSON.stringify(users, null, 2));
}}} 

var upload = multer()
var app = express()

app.get('/login',(req, res) => {
res.sendFile(path.join(__dirname, "./public/", "login.html"))}); 
app.get('/planos',(req, res) => {
res.sendFile(path.join(__dirname, "./public/", "planos.html"))}); 
app.get('/dash',(req, res) => {
res.sendFile(path.join(__dirname, "./public/", "docs.html"))});
app.get('/',(req, res) => {
res.sendFile(path.join(__dirname, "./public/", "index.html"))}); 
app.get('/panel',(req, res) => {
res.sendFile(path.join(__dirname, "./public/", "admin.html"))}); 
 
app.use(cors())
app.set("json spaces",2)
app.use(express.static("public"))
app.use(router);

app.get('/fundo.mp4', function(req, res){
    res.sendFile(__dirname + "/imgs/index.mp4")
});
 

// Rota para verificar o IP
app.get('/ip', (req, res) => {
  const ipCliente = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  res.json({
    ip_local: Object.values(os.networkInterfaces())
      .flat()
      .find(i => i.family === 'IPv4' && !i.internal)?.address,
    ip_publico: req.ip,
    ip_cliente: ipCliente
  });
});
 
 
app.get('/api/keyerrada',(req, res) => {
;

if(ITC < 0) {
return res.json({key:'Sua apikey é invalida!!'})
} else {return res.json({key:`Sua apikey está 100% • Requisições Restantes: ${key[ITC]?.request}`})}})

app.get('/api/status/key',(req, res) => {
;

if(ITC < 0) {
return res.json({key:' ❌ Sua apikey é invalida!! ❌'})
} else {return res.json({key:`${key[ITC]?.request}`})}
})

app.get('/api/status/apikey',(req, res) => {
;
if(key.map(i => i.apikey).includes(apikey)) {
return res.json({resultado: "Essa key já está inclusa dentro do sistema.."})
} else {
return res.json({resultado: `Não está inclusa`})
}
})
 
app.get('/api/add-key',(req, res) => {
a = req.query.a
if(!a.includes("&")) return res.json({resultado: "Faltando o and"})
var [apikey, senha, rq] = a.split("&")
var senhaofc = "pedrozzSenha"
if(senha != senhaofc) return res.json({resultado: "Senha invalida.."})
if(!apikey) return res.json({resultado: "Kd a key.."})
if(key.map(i => i.apikey).includes(apikey)) {
return res.json({resultado: "Essa key já está inclusa dentro do sistema.."})
} else {
key.push({apikey: apikey, request: rq})
fs.writeFileSync("./lib/secret/keys.json", JSON.stringify(key))

return res.json({resultado: `apikey: ${apikey} Foi Adicionada ao Sistema com Exito!\nNumero de Requisições Disponiveis: ${key[ITC]?.request}`})
}
})
 
app.get('/api/del-key',(req, res) => {
a = req.query.a
if(!a.includes("&")) return res.json({resultado: "Faltando o and"})
var [apikey, senha] = a.split("&")
var senhaofc = "pedrozzSenha"
if(senha != senhaofc) return res.json({resultado: "Senha invalida.."})
if(!apikey) return res.json({resultado: "Kd a key.."})
if(!key.map(i => i.apikey).includes(apikey)) {
return res.json({resultado: "Essa key não está inclusa.."})
} else {
var i2 = key.map(i => i.apikey).indexOf(apikey)
key.splice(i2, 1)
fs.writeFileSync("./lib/secret/keys.json", JSON.stringify(key))
return res.json({resultado: `🔑 apikey ${apikey} deletada com sucesso..`})
}
}) 
 
app.get('/api/add-request',(req, res) => {

if(!apikey.includes("&")) return res.json({resultado: "Faltando o and"})
var [apikey, senha, rq] = apikey.split("&")
if(!apikey) return res.json({resultado: "❌ Sua apikey está incorreta, Porfavor Revise como está escrito!"})

if(!key.map(i => i.apikey).includes(apikey)) {
return res.json({resultado: "❌ Sua apikey está incorreta, Porfavor Revise como está escrito!"})
} else {
const rqL = `${rq}`;
var soma2 = rqL.replace(/"/g, '');
const reqL = `${key[ITC]?.request}`;
var soma1 = reqL.replace(/"/g, '');
const stringNumero1 = soma1; 
const numero1 = parseInt(stringNumero1); 
const stringNumero2 = soma2; 
const numero2 = parseInt(stringNumero2); 
var soma = numero2 + numero1;
var senhaofc = "pedrozzSenha"
if(senha != senhaofc) return res.json({resultado: "Senha invalida.."})
var i2 = key.map(i => i.apikey).indexOf(apikey)
key.splice(i2, 1)
fs.writeFileSync("./lib/secret/keys.json", JSON.stringify(key))
key.push({apikey: apikey, request: soma})
fs.writeFileSync("./lib/secret/keys.json", JSON.stringify(key))

return res.json({resultado: `🚀 Novo Numero de Requisições Disponiveis: ${key[ITC]?.request}`})
} 
})


app.get('/loli', (req, res) => {
(async() => {

json = JSON.parse(fs.readFileSync('lib/lolis.json').toString())
random = json[Math.floor(Math.random() * json.length)]
res.type('jpg')
res.send(await getBuffer(random))
})()
})

app.get('/shota', (req, res) => {
(async() => {
json = JSON.parse(fs.readFileSync('lib/shotas.json').toString())
random = json[Math.floor(Math.random() * json.length)]
res.type('jpg')
res.send(await getBuffer(random))
})()
})

app.get('/random/metadinha', async (req, res, next) => {
         json = JSON.parse(fs.readFileSync(bla +'/lib/metadinha.json').toString())
         random = json[Math.floor(Math.random() * json.length)]
         res.json(random) 
})
 
app.get('/+18/loli', (req, res) => {
(async() => {
json = JSON.parse(fs.readFileSync('lib/nsfwlolis.json').toString())
random = json[Math.floor(Math.random() * json.length)]
res.type('jpg')
res.send(await getBuffer(random))
})()
})

app.get('/api/facebook', async(req, res, next) => {

url = req.query.url
 if (!url) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: url"})
fbdown(url).then(data => {
res.json({
status: true,
resultado: "💞ZERO TWO RESET API'S - MELHOR SITE DE APIS💞",
criador: `${criador}`,
resultado: data
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})


router.all('/api/instamp4', async (req, res) => {
url = req.query.url
if(!url)return res.json({
status:false,
motivo:'Coloque o parâmetro: url'
})
try {
instavideo = await igdl(url)
res.json({
status: true,
resultado: "💞ZERO TWO RESET API'S - MELHOR SITE DE APIS💞",
criador: `${criador}`,
resultado: instavideo.resultado[0].link_dl,
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
}) 

router.get('/api/canvas/musicard', async(req, res, next) => {
var { thumbnail, music_name, artist_name, time_end } = req.query;
if(!thumbnail) return res.json({message: "Faltando o parâmetro: 'thumbnail'"});
if(!music_name) return res.json({message: "Faltando o parâmetro: 'music_name'"});
if(!artist_name) return res.json({message: "Faltando o parâmetro: 'artist_name'"});
if(!time_end) return res.json({message: "Faltando o parâmetro: 'time_end'"});
const MusicCard = await Classic({
    thumbnailImage: thumbnail,
    backgroundColor: "#070707",
    progress: 10,
    progressColor: "#FF7A00",
    progressBarColor: "#5F2D00",
    name: music_name,
    nameColor: "#FF7A00",
    author: artist_name,
    authorColor: "#696969",
    startTime: "0:00",
    endTime: time_end,
    timeColor: "#FF7A00"
});
require('fs').writeFileSync(bla + "/assets/Tempo/musicard.png", MusicCard);
res.sendFile(bla + '/assets/Tempo/musicard.png');
});

router.all('/api/info_celular', async (req, res) => {
celular = req.query.celular
if(!celular)return res.json({status:false, motivo:'Coloque o parâmetro: celular'})
auu = await fetchJson(`http://br3.bronxyshost.com:3039/api-bronxys/info_celular?celular=${celular}&apikey=daniel_dzn`)
res.json({
status: true,
resultado: "💞ZERO TWO RESET API'S - MELHOR SITE DE APIS💞",
criador: `${criador}`,
resultado: {
nomeCelular: `${auu.celular}`,
informações: `${auu.infoc}`,
resumoExtra: `${auu.resumo}`
}
})
})


app.get('/api/happymod', async(req, res, next) => {
q = req.query.q
if (!q) return res.json({ status : false, creator : `${criador}`, resultado : "Cade o parametro q?"}) 
  if(key.includes(apikey)){
    fetch(encodeURI(`https://p7api.xyz/api/happymod?nome=${q}&apikey=6bb2f5-22a158-0441f9-6b4308-115f0f`))
    .then(response => response.json())
        .then(hasil => {

        var resultado = hasil.resultado;
             res.json({
                 status: true,
                 criador: `${criador}`,
                 resultado
             })
         })
         .catch(e => {
         	res.json({resultado: `${msgerro}`})
})
} else {
  res.json({resultado: `${msgerro}`})
}
})

app.get('/search/pensador', async(req,res) => {
query = req.query.query
if(!query)return res.json({
status:false, 
resultado:'Cadê o parâmetro: QUERY'
})
pensadorSearch(query)
.then(dados => {
res.json({
status:true,
criador: `${criador}`,
resultado: dados
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

const GPTI = require('gpti'); // Importe seu módulo GPTI

// Middleware para parsear JSON
app.use(express.json());

// ✅ Rota GET (simples) e POST (avançado)
app.get('/gpti', async (req, res) => {
    try {
        const { prompt } = req.query;

        if (!prompt) {
            return res.status(400).json({
                error: "Parâmetro 'prompt' obrigatório",
                example: "/gpti?prompt=Como criar uma API?"
            });
        }

        const response = await GPTI.generate({
            prompt,
            temperature: 0.7 // Valor padrão
        });

        res.json({
            prompt,
            response,
            model: "GPTI-Local",
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error("Erro:", error);
        res.status(500).json({ 
            error: "Internal Server Error",
            details: error.message 
        });
    }
});

// ✅ Rota POST (para prompts complexos)
app.post('/gpti', async (req, res) => {
    try {
        const { 
            prompt,
            history = [],
            temperature = 0.7,
            max_length = 500
        } = req.body;

        if (!prompt) {
            return res.status(400).json({
                error: "Campo 'prompt' é obrigatório"
            });
        }

        const response = await GPTI.generate({
            prompt,
            history,
            temperature,
            max_length
        });

        res.json({
            prompt,
            response,
            history: [...history, { role: "user", content: prompt }],
            parameters: {
                temperature,
                max_length
            },
            model: "GPTI-Pro",
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error("Erro:", error);
        res.status(500).json({ 
            error: "Internal Server Error",
            details: error.message 
        });
    }
});

app.get('/search/wallpaper', async(req,res) => {
query = req.query.query
if(!query)return res.json({
status:false,
resultado:'Cadê o parâmetro: QUERY'
})
wallpaper2(query)
.then(result => {
res.json({
status:true,
criador: `${criador}`,
resultado: result
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})
  
app.get('/api/gethtml', async(req,res) => {
query = req.query.query
if(!query)return res.json({status:false,resultado:'Cadê o parâmetro: QUERY'})
try {
axios.get(`${query}`).then(a => {
res.json({
status:true,
criador: `${criador}`,
resultado: JSON.stringify(a.data, null, 2)
})
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/api/print-site', async (req, res, next) => {
var query = req.query.query 
if(!query)return res.json({status:false,motivo:'Cadê o parâmetro query?'})
try {
    hasil = `https://api.popcat.xyz/screenshot?url=${query}`
	  data = await fetch(hasil).then(v => v.buffer())   
         await fs.writeFileSync(bla+'/tmp/gostosinha.png', data)
        res.sendFile(bla+'/tmp/gostosinha.png')
} catch (err) {
res.json({resultado: `${msgerro}`})
}; 
}) 


app.get('/api/brasileirao', async(req,res) => {
try {
const { BrasileiraoSearch } = require('./modulos-api/BrasileiraoSearch.js')
await BrasileiraoSearch().then(result => {	
res.json({
status: true,
criador: `${criador}`,
creditos_scrapper: '@AtroxDev',
resultado: result,
})
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/download/tiktok', async(req,res) => {
url = req.query.url
if(!url)return res.json({
status:false,
resultado:'Cadê o parâmetro: URL'
})
tiktok2(url).then(result => {
res.json({
status:true,
criador: `${criador}`,
resultado: result
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/download/facebook', async(req, res, next) => {
url = req.query.url
 if (!url) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: url"})
FacebookMp4(url).then(resultado => {
res.json({
status: true,
resultado: "💞ZERO TWO RESET API'S - MELHOR SITE DE APIS💞",
criador: `${criador}`,
resultado: resultado
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/filme', async(req, res, next) => {
q = req.query.q
 if (!q) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: q"})
filme(q).then(resultado => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
code_by: `@Gabriel`,
pesquisa: resultado
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})


app.get('/api/pornogratis', async(req, res, next) => {
q = req.query.q
 if (!q) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: q"})
 pornogratis(q).then(resultado => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: resultado
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})


app.get('/api/nerding', async(req, res, next) => {
q = req.query.q
 if (!q) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: q"})
 nerding(q).then(resultado => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: resultado
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})


app.get('/api/playstore', async(req, res, next) => {
nome = req.query.nome
 if (!nome) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: nome"})
PlayStoreSearch(nome).then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/mercadolivre', async(req, res, next) => {
nome = req.query.nome
 if (!nome) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: nome"})
mercadoLivreSearch2(nome).then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/amazon', async(req, res, next) => {
nome = req.query.nome
 if (!nome) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: nome"})
AmazonSearch(nome).then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/pinterest_mp4', async(req, res, next) => {
url = req.query.url
if (!url) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: url"})
pinterestVideoV2(url).then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/americanas', async(req, res, next) => {
nome = req.query.nome
 if (!nome) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: nome"})
AmericanasSearch(nome).then(dados => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})


app.get('/api/submarino', async(req, res, next) => {
nome = req.query.nome
 if (!nome) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: nome"})
SubmarinoSearch(nome).then(dados => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})


app.get('/api/horoscopo', async(req, res, next) => {
signo = req.query.signo
if (!signo) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: signo"})
Horoscopo(signo).then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/randomgp', async(req, res, next) => {
categoria = req.query.categoria
 if (!categoria) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: categoria"})
randomGrupos(categoria).then(dados => {
res.json({
pesquisa: dados
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/download/kwai', async(req, res, next) => {
url = req.query.url
if (!url) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: url"})
kwai(url).then(hasil => {
res.json({
status: 200,
criador: `${criador}`,
resultado: hasil
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/outros/openai', async(req, res, next) => {
pergunta = req.query.pergunta
 if (!pergunta) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: pergunta"})
InArtificial(pergunta).then(hasil => {
res.json({
status: 200,
criador: `${criador}`,
resultado: hasil
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/outros/openai/corretor', async(req, res, next) => {
texto = req.query.texto
 if (!texto) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: texto"})
CorretorOpenAi(texto).then(hasil => {
res.json({
status: 200,
criador: `${criador}`,
resultado: hasil
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/memes', async(req, res, next) => {
memesDroid().then(dados => {
res.json({
pesquisa: dados
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/ringtone', async(req, res, next) => {
query = req.query.query
  if (!query) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: query"})
ringtone(query).then(hasil => {
res.json({
status: 200,
criador: `${criador}`,
resultado: hasil
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/noticias/globo', async(req, res, next) => {
G1().then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/noticias/jovempan', async(req, res, next) => {
JovemPan().then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/noticias/poder360', async(req, res, next) => {
Poder360().then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/noticias/uol', async(req, res, next) => {
Uol().then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/noticias/estadao', async(req, res, next) => {
Estadao().then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/noticias/cnnbrasil', async(req, res, next) => {
CNNBrasil().then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/gpwhatsapp', async(req, res, next) => {
q = req.query.q;
  if(!q)return res.json({status:false,resultado:'Cadê o parâmetro q?'})
 gpwhatsapp(q).then(resultado => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: resultado
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})


app.get('/api/apkmody', async(req, res) => {
    const q = req.query.q;
    
    if (!q) {
        return res.json({ 
            status: false, 
            message: "Parâmetro 'q' é obrigatório" 
        });
    }

    try {
        const response = await fetch(encodeURI(`https://yub1lok-api.onrender.com/api/pesquisa/apkmody?nome=${q}`));
        const data = await response.json();
        
        res.json({
            status: true,
            resultado: data.resultado || data
        });
        
    } catch (e) {
        res.status(500).json({
            status: false,
            message: "Erro ao buscar no APKMody"
        });
    }
});


app.get('/api/freefire', async(req, res, next) => {
q = req.query.q
if (!q) return res.json({ status : false, creator : `${criador}`, resultado : "Cade o parametro q?"}) 
  if(key.includes(apikey)){
    fetch(encodeURI(`https://ayu.p7api.xyz/api/pesquisa/ff?nome=${q}&apikey=6bb2f5-22a158-0441f9-6b4308-115f0f`))
    .then(response => response.json())
        .then(hasil => {

        var resultado = hasil.resultado;
             res.json({
                 status: true,
                 criador: `${criador}`,
                 resultado
             })
         })
         .catch(e => {
         	res.json({resultado: `${msgerro}`})
})
} else {
  res.json({resultado: `${msgerro}`})
}
})

app.get('/api/rexdl', async(req, res, next) => {
q = req.query.q
if (!q) return res.json({ status : false, creator : `${criador}`, resultado : "Cade o parametro q?"}) 
  if(key.includes(apikey)){
    fetch(encodeURI(`https://p7api.xyz/api/rexdl?nome=${q}&apikey=6bb2f5-22a158-0441f9-6b4308-115f0f`))
    .then(response => response.json())
        .then(hasil => {

        var resultado = hasil.resultado;
             res.json({
                 status: true,
                 criador: `${criador}`,
                 resultado
             })
         })
         .catch(e => {
         	res.json({resultado: `${msgerro}`})
})
} else {
  res.json({resultado: `${msgerro}`})
}
})

app.get('/api/moddroid', async(req, res, next) => {
q = req.query.q
if (!q) return res.json({ status : false, creator : `${criador}`, resultado : "Cade o parametro q?"}) 
  if(key.includes(apikey)){
    fetch(encodeURI(`https://p7api.xyz/api/moddroid?nome=${q}&apikey=6bb2f5-22a158-0441f9-6b4308-115f0f`))
    .then(response => response.json())
        .then(hasil => {

        var resultado = hasil.resultado;
             res.json({
                 status: true,
                 criador: `${criador}`,
                 resultado
             })
         })
         .catch(e => {
         	res.json({resultado: `${msgerro}`})
})
} else {
  res.json({resultado: `${msgerro}`})
}
})

app.get('/api/sfile', async(req, res, next) => {
q = req.query.q
if (!q) return res.json({ status : false, creator : `${criador}`, resultado : "Cade o parametro q?"}) 
  if(key.includes(apikey)){
    fetch(encodeURI(`https://p7api.xyz/api/sfile?nome=${q}&apikey=6bb2f5-22a158-0441f9-6b4308-115f0f`))
    .then(response => response.json())
        .then(hasil => {

        var resultado = hasil.resultado;
             res.json({
                 status: true,
                 criador: `${criador}`,
                 resultado
             })
         })
         .catch(e => {
         	res.json({resultado: `${msgerro}`})
})
} else {
  res.json({resultado: `${msgerro}`})
}
})


router.all('/api/musicas/itunes', async (req, res) => {
musica = req.query.musica
if(!musica)return res.json({
status:false,
motivo:'Coloque o parâmetro: musica'
})
auu = await fetchJson(`https://api.popcat.xyz/itunes?q=${musica}`)
res.json({
status: true,
resultado: "💞ZERO TWO RESET API'S - MELHOR SITE DE APIS💞",
criador: `${criador}`,
resultado: {
linkAcesso: `${auu.url}`,
nomeMusic: `${auu.name}`,
nomeArtista: `${auu.artist}`,
nomeAlbum: `${auu.album}`,
lançamento: `${auu.release_date}`,
preço: `${auu.price}`,
segundos: `${auu.length}`,
gênero: `${auu.genre}`,
thumbnail: `${auu.thumbnail}`
}
})
})


app.get('/shortlink/tinyurl', async (req, res, next) => {







TinyUrl.shorten(url, function(url, err) {
  if (err) return res.json(loghandler.error)
	res.json({
		status: true,
		criador: `${criador}` ,
		result: url
		})
}); 
})

app.get('/shortlink/cuttly', async (req, res, next) => {







url = req.query.url
if(!url)return res.json({
status:false,
resultado:'Cade o parametro url??'
})
	var hasil = await fetchJson(`https://cutt.ly/api/api.php?key=${randomapicuttly}&short=${url}`)
  if (!hasil.url.shortLink ) return res.json('Error')

	res.json({
		status: true,
		criador: `${criador}` ,
		result: hasil.url.shortLink
		})
});

app.get('/shortlink/bitly', async (req, res, next) => {

url = req.query.url
if(!url)return res.json({
status:false,
resultado:'Cade o parametro url??'
})
	let randomapibitly = apibitly[Math.floor(Math.random() * apibitly.length)]
	const bitly = new BitlyClient(randomapibitly)
	bitly.shorten(url).then(function(result) {
		res.json({
			status: true,
			criador: `${criador}` ,
			result : result.link
			})
	 
	})
	.catch(function(error) {
	 res.json(`${error}`)
	});
})

app.get('/api/igstory', async (req, res, next) => {
          
url = req.query.url







url = req.query.url
if(!url)return res.json({
status:false,
resultado:'Cade o parametro url??'
})
if (!url) return res.json({ status : false, creator : `${criador}`, resultado : "Cade o parametro url?"}) 
        if(key.includes(apikey)){
       igstory(url)
	.then(data => {
		var result = data;
		res.json({
			result
		})
		})
         .catch(e => {
         	console.log(e);
         	res.json({resultado: `${msgerro}`})
})
} else {
  res.json({resultado: `${msgerro}`})
}
})

app.get('/api/simi', async (req, res, next) => {







text = req.query.text
if (!text) return res.json({ status : false, creator : `${criador}`, resultado : "Cade o parametro text?"})
        if(key.includes(apikey)){
       fetch(encodeURI(`https://api.simsimi.net/v2/?text=${text}&lc=pt`))
        .then(response => response.json())
        .then(data => {
        var result = data.success;
             res.json({
                 result
             })
         })
         .catch(e => {
         	console.log(e);
         	res.json({resultado: `${msgerro}`})
})
} else {
  res.json({resultado: `${msgerro}`})
}
})


app.get('/api/ttp2', async (req, res, next) => {
var texto = req.query.texto
      if(!texto)return res.json({status:false, motivo:'Cadê o parâmetro texto?'})

	if(key.includes(apikey)){    
    hasil = `http://br3.bronxyshost.com:3039/api-bronxys/ttp?texto=${texto}&apikey=daniel_dzn`
       res.send(await getBuffer(hasil))
         } else {
  res.json({resultado: `${msgerro}`})
}    
})

app.get('/api/fazernick', async (req, res) => {
  






let nome = req.query.nome || res.json({resultado: 'insira o parâmetro: ?nome='})
await gerarnick(nome)
.then(nicks => {
res.send(nicks) 
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/mediafire', async (req, res, next) => {







url = req.query.url
if (!url) return res.json({ status : false, creator : `${criador}`, resultado : "Cade o parametro url?"})
mediafire(url)
.then(data => {
var resultado = data;
res.json({
resultado
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})


app.get('/api/wikimedia', async (req, res, next) => {







query = req.query.query
if (!query) return res.json({ status : false, creator : `${criador}`, resultado : "Cade o parametro query?"})
wikimedia(query)
.then(hasil => {
var resultado = hasil;
res.json({
https_code: 200,
criador: "@VNCSCODE - 73999197974",
resultado
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/gimage', async(req,res) => {







txt = req.query.txt
if(!txt) return res.json({resultado: "Faltando o parametro txt"})
GOOGLE_IMG_SCRAP({
search: txt,
query: {
EXTENSION: GOOGLE_QUERY.EXTENSION.JPG
},
limit: 5,
domains: ["alamy.com", "istockphoto.com", "vecteezy.com", "pinterest.com", "google.com"],
excludeWords: ["black", "white"], //If you don't like black and white cats
custom: "name=content&name2=content2",
safeSearch: false,
 // excludeDomains: ["istockphoto.com", "alamy.com"]
}).then(e => {
resultado = e
res.json({
resultado
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
}) 
})

app.get('/api/pinterest', (req, res) => {
(async() => {
text = req.query.text
if (!text) return res.json({ status : false, creator : `${criador}`, resultado : "Cade o parametro text?"})
pin = await pinterest(text)
ac = pin[Math.floor(Math.random() * pin.length)]
res.type('jpg')
res.send(await getBuffer(ac))
})()
})

app.get('/api/wattpad',  async (req, res, next) => {
query = req.query.query
if (!query) return res.json({ status : false, creator : `${criador}`, resultado : "Cade o parametro query?"})
wattpad(query).then(result => {
res.json({
criador: `${criador}`,
resultado: result
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})
 

app.get('/outros/disney', async (req, res) => {







  try {
    var response = await fetchJson('https://pastebin.com/raw/LUvekhW4');
    var data = await response.json();
    var accounts = data.disney;
    var randomIndex = Math.floor(Math.random() * accounts.length);
    var randomAccount = accounts[randomIndex];
    var totalAccounts = accounts.length;

    return res.json({ DONO: `${criador}`, ...randomAccount, "total": '🩸 | *QUANTIDADE RESTANTE:* ' + totalAccounts, "resultado": '❗ | *OBS:* ' + 'Não Mude nenhuma senha, eu saberei que foi vc!' })
  } catch (error) {
    return res.status(500).json({ resposta: "Erro ao obter contas", status: 500 });
  } 
});

app.get('/api/figurinhas', async (req, res) => {







  try {
	  const fig = `${Math.floor(Math.random() * 373)}`
          popopoc = fs.readFileSync(`./lib/figs/${fig}.webp`)
         await fs.writeFileSync(bla+'/tmp/gostosinha.jpg', popopoc)
        res.sendFile(bla+'/tmp/gostosinha.jpg') 
  } catch (error) {
    return res.status(500).json({ resposta: `${error}`, status: 500 });
  }
});


app.get('/outros/combo', async (req, res) => {







  try {
    var response = await fetchJson('https://pastebin.com/raw/wniFNhqp');
    var data = await response.json();
    var accounts = data.combo;
    var randomIndex = Math.floor(Math.random() * accounts.length);
    var randomAccount = accounts[randomIndex];
    var totalAccounts = accounts.length;

    return res.json({ DONO: `${criador}`, ...randomAccount, "total": '🩸 | *QUANTIDADE RESTANTE:* ' + totalAccounts, "resultado": '❗ | *OBS:* ' + 'Não Mude nenhuma senha, eu saberei que foi vc!' })
  } catch (error) {
    return res.status(500).json({ resposta: "Erro ao obter contas", status: 500 });
  }
});

app.get('/outros/ufc', async (req, res) => {







  try {
    var response = await fetchJson('https://pastebin.com/raw/2DbNi67C');
    var data = await response.json();
    var accounts = data.ufc;
    var randomIndex = Math.floor(Math.random() * accounts.length);
    var randomAccount = accounts[randomIndex];
    var totalAccounts = accounts.length;

    return res.json({ DONO: `${criador}`, ...randomAccount, "total": '🩸 | *QUANTIDADE RESTANTE:* ' + totalAccounts, "resultado": '❗ | *OBS:* ' + 'Não Mude nenhuma senha, eu saberei que foi vc!' })
  } catch (error) {
    return res.status(500).json({ resposta: "Erro ao obter contas", status: 500 });
  }
});

app.get('/outros/sp-pni', async (req, res) => {







  try {
	var sppni = ["✅ | *LOGIN SP-PNI*\n\n👤 | *USUARIO:* cleoniceferreirapinho@hotmail.com\n🔐 | *SENHA:* gentileza10$\\n\n💠 |  *SITE:* https://si-pni.saude.gov.br/" , "✅ | *LOGIN SP-PNI*\n\n👤 | *USUARIO:* veradaiana18@gmail.com\n🔐 | *SENHA:* 009935V.m\\n\n💠 |  *SITE:* https://si-pni.saude.gov.br/"]
    var logins = sppni[Math.floor(Math.random() * sppni.length)]
 return res.json({
 status: true,
 código: 200,
 criador: `${criador}`,
 conta: `${logins}`,
 })} catch (error) {
    return res.status(500).json({ resposta: "Erro ao obter contas", status: 500 });
  }
});

app.get('/outros/credlink', async (req, res) => {







  try {
	var credlink = ["✅ | *LOGIN CREDILINK*\n\n👤 | *USUARIO:* COTEL00045\n🔐 | *SENHA:* gABRIEL@31\\n\n💠 |  *SITE:* https://consulta5.confirmeonline.com.br/" , "✅ | *LOGIN CREDILINK*\n\n👤 | *USUARIO:* lafer\n🔐 | *SENHA:* 7AR32Qinfo\\n\n💠 |  *SITE:* https://consulta5.confirmeonline.com.br/"]
    var logins = credlink[Math.floor(Math.random() * credlink.length)]
 return res.json({
 status: true,
 código: 200,
 criador: `${criador}`,
 conta: `${logins}`,
 })} catch (error) {
    return res.status(500).json({ resposta: "Erro ao obter contas", status: 500 });
  }
});

app.get('/outros/pmrj', async (req, res) => {







  try {
	var pmrj = ["✅ | *LOGIN PM RJ*\n\n👤 | *USUARIO:* 12670489729\n🔐 | *SENHA:* 2664870p\\n\n💠 |  *SITE:* http://portal.pmerj.rj.gov.br" , "✅ | *LOGIN CREDILINK*\n\n👤 | *USUARIO:* 15720631739\n🔐 | *SENHA:* mdf91252\\n\n💠 |  *SITE:* http://portal.pmerj.rj.gov.br"]
    var logins = pmrj[Math.floor(Math.random() * pmrj.length)]
 return res.json({
 status: true,
 código: 200,
 criador: `${criador}`,
 conta: `${logins}`,
 })} catch (error) {
    return res.status(500).json({ resposta: "Erro ao obter contas", status: 500 });
  }
});


app.get('/outros/express', async (req, res) => {







  try {
    var response = await fetchJson('https://pastebin.com/raw/ZeHyNQji');
    var data = await response.json();
    var accounts = data.epress;
    var randomIndex = Math.floor(Math.random() * accounts.length);
    var randomAccount = accounts[randomIndex];
    var totalAccounts = accounts.length;
    return res.json({ DONO: `${criador}`, ...randomAccount, "total": '🩸 | *QUANTIDADE RESTANTE:* ' + totalAccounts, "resultado": '❗ | *OBS:* ' + 'Não Mude nenhuma senha, eu saberei que foi vc!' })
  } catch (error) {
    return res.status(500).json({ resposta: "Erro ao obter contas", status: 500 });
  }
});

app.get('/outros/paramount', async (req, res) => {







  try {
    var response = await fetchJson('https://pastebin.com/raw/LDit28EV');
    var data = await response.json();
    var accounts = data.paramount;
    var randomIndex = Math.floor(Math.random() * accounts.length);
    var randomAccount = accounts[randomIndex];
    var totalAccounts = accounts.length;
    return res.json({ DONO: `${criador}`, ...randomAccount, "total": '🩸 | *QUANTIDADE RESTANTE:* ' + totalAccounts, "resultado": '❗ | *OBS:* ' + 'Não Mude nenhuma senha, eu saberei que foi vc!' })
  } catch (error) {
    return res.status(500).json({ resposta: "Erro ao obter contas", status: 500 });
  }
});

app.get('/outros/crunchyroll', async (req, res) => {







  try {
    var response = await fetchJson('https://pastebin.com/raw/QP7m9Tb1');
    var data = await response.json();
    var accounts = data.crunchyroll;
    var randomIndex = Math.floor(Math.random() * accounts.length);
    var randomAccount = accounts[randomIndex];
    var totalAccounts = accounts.length;
    return res.json({ DONO: `${criador}`, ...randomAccount, "total": '🩸 | *QUANTIDADE RESTANTE:* ' + totalAccounts, "resultado": '❗ | *OBS:* ' + 'Não Mude nenhuma senha, eu saberei que foi vc!' })
  } catch (error) {
    return res.status(500).json({ resposta: "Erro ao obter contas", status: 500 });
  }
});

app.get('/outros/deezer', async (req, res) => {







  try {
    var response = await fetchJson('https://pastebin.com/raw/N3YNKitQ');
    var data = await response.json();
    var accounts = data.deezer;
    var randomIndex = Math.floor(Math.random() * accounts.length);
    var randomAccount = accounts[randomIndex];
    var totalAccounts = accounts.length;
    return res.json({ DONO: `${criador}`, ...randomAccount, "total": '🩸 | *QUANTIDADE RESTANTE:* ' + totalAccounts, "resultado": '❗ | *OBS:* ' + 'Não Mude nenhuma senha, eu saberei que foi vc!' })
  } catch (error) {
    return res.status(500).json({ resposta: "Erro ao obter contas", status: 500 });
  }
});

app.get('/outros/nordvpn', async (req, res) => {







  try {
    var response = await fetchJson('https://pastebin.com/raw/s6v8pe61');
    var data = await response.json();
    var accounts = data.nordvpn;
    var randomIndex = Math.floor(Math.random() * accounts.length);
    var randomAccount = accounts[randomIndex];
    var totalAccounts = accounts.length;
    return res.json({ DONO: `${criador}`, ...randomAccount, "total": '🩸 | *QUANTIDADE RESTANTE:* ' + totalAccounts, "resultado": '❗ | *OBS:* ' + 'Não Mude nenhuma senha, eu saberei que foi vc!' })
  } catch (error) {
    return res.status(500).json({ resposta: "Erro ao obter contas", status: 500 });
  }
});

app.get('/outros/star', async (req, res) => {







  try {
    var response = await fetchJson('https://pastebin.com/raw/f6N5RWWN');
    var data = await response.json();
    var accounts = data.star;
    var randomIndex = Math.floor(Math.random() * accounts.length);
    var randomAccount = accounts[randomIndex];
    var totalAccounts = accounts.length;
    return res.json({ DONO: `${criador}`, ...randomAccount, "total": '🩸 | *QUANTIDADE RESTANTE:* ' + totalAccounts, "resultado": '❗ | *OBS:* ' + 'Não Mude nenhuma senha, eu saberei que foi vc!' })
  } catch (error) {
    return res.status(500).json({ resposta: "Erro ao obter contas", status: 500 });
  }
});

app.get('/outros/netflix', async (req, res) => {







  try {
    var response = await fetchJson('https://pastebin.com/raw/wxwriPvj');
    var data = await response.json();
    var accounts = data.netflix;
    var randomIndex = Math.floor(Math.random() * accounts.length);
    var randomAccount = accounts[randomIndex];
    var totalAccounts = accounts.length;
    return res.json({ DONO: `${criador}`, ...randomAccount, "total": '🩸 | *QUANTIDADE RESTANTE:* ' + totalAccounts, "resultado": '❗ | *OBS:* ' + 'Não Mude nenhuma senha, eu saberei que foi vc!' })
  } catch (error) {
    return res.status(500).json({ resposta: "Erro ao obter contas", status: 500 });
  }
});

app.get('/outros/hbomax', async (req, res) => {







  try {
    var response = await fetchJson('https://pastebin.com/raw/KCeP320a');
    var data = await response.json();
    var accounts = data.hbomax;
    var randomIndex = Math.floor(Math.random() * accounts.length);
    var randomAccount = accounts[randomIndex];
    var totalAccounts = accounts.length;
    return res.json({ DONO: `${criador}`, ...randomAccount, "total": '🩸 | *QUANTIDADE RESTANTE:* ' + totalAccounts, "resultado": '❗ | *OBS:* ' + 'Não Mude nenhuma senha, eu saberei que foi vc!' })
  } catch (error) {
    return res.status(500).json({ resposta: "Erro ao obter contas", status: 500 });
  }
});


app.get('/api/xnxxsearch', async(req, res, next) => {







q = req.query.q
 if (!q) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: q"})
xnxxsearch(q).then(result => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: result
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/pornhubsearch', async(req, res, next) => {







q = req.query.q
 if (!q) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: q"})
pornhub(q).then(result => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: result
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})
 

app.get('/api/xvideossearch', async(req, res, next) => {







q = req.query.q
if (!q) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: q"})
var { xvideosSearch } = require('./modulos-api/scrapperlinda.js')
xvideosSearch(q).then(result => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: result
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})



app.get('/api/xvideosdw', async(req, res, next) => {







url = req.query.url
if (!url) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: q"})
var { xvideosDownloader } = require('./modulos-api/scrapperlinda.js')
xvideosDownloader(url).then(result => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: result
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/uptodown', async(req, res, next) => {







q = req.query.q
if (!q) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: q"})
const { Uptodown } = require('./modulos-api/uptodown.js')
Uptodown(q).then(resultado => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: resultado
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/hackneon', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().Ephoto360("https://en.ephoto360.com/create-anonymous-hacker-avatars-cyan-neon-677.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/github', (req,res,next) => {
pessoa = req.query.usuario






if(!pessoa)return res.json({
status:false,
motivo:'cade_o_usuario'
})
fetch(encodeURI(`https://api.github.com/users/`+pessoa))
.then(response => response.json())
.then(date => {
gitData =  date;
res.json({
criador:"EliasModder",
status:true,
resultado:{
username: gitData.login,
id: gitData.id,
Node_ID: gitData.node_id,
url: gitData.html_url,
local: (gitData.location == null) ? 'não_tem' : gitData.location,
bio: (gitData.bio == null) ? 'não_tem' : gitData.bio,
twitter:  (gitData.twitter_username == null) ? 'não_tem' : gitData.twitter_username,
seguidores: gitData.followers,
seguindo: gitData.following,
criado: gitData.created_at,
atualizado: gitData.updated_at,
procura_trabalho: (gitData.hireable == null) ? 'Não' : gitData.hireable,
Site: (gitData.blog == "") ? 'Não' : gitData.blog,
repositorios: gitData.public_repos,
admin_de_Site: (gitData.site_admin == false) ? 'Não' : gitData.site_admin,
tipo: gitData.type,
empresa: (gitData.company == null) ? 'Não' : gitData.company,
email: (gitData.email == null) ? 'Não' : gitData.email
} 
})
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/api/fpsmascote', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().Ephoto360("https://en.ephoto360.com/free-gaming-logo-maker-for-fps-game-team-546.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/equipemascote', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().Ephoto360("https://en.ephoto360.com/make-team-logo-online-free-432.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/txtquadrinhos', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().Ephoto360("https://en.ephoto360.com/boom-text-comic-style-text-effect-675.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/ffavatar', async(req, res, next) => {
texto = req.query.texto;
if(!texto) return res.json({resultado: "Cade o parametro texto"})







new Maker().Ephoto360("https://en.ephoto360.com/create-free-fire-avatar-online-572.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/ffbanner', async(req, res, next) => {
texto = req.query.texto;
texto2 = req.query.texto2;
if(!texto) return res.json({resultado: "Cade o parametro texto"})
if(!texto2) return res.json({resultado: "Cade o parametro texto2"})







new Maker().Ephoto360("https://en.ephoto360.com/make-your-own-free-fire-youtube-banner-online-free-562.html", [`${texto}`, `${texto2}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/mascotegame', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().Ephoto360("https://en.ephoto360.com/create-a-gaming-mascot-logo-free-560.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/mascoteavatar', async(req, res, next) => {
texto = req.query.texto;
texto2 = req.query.texto2;
if(!texto) return res.json({resultado: "Cade o parametro texto"})
if(!texto2) return res.json({resultado: "Cade o parametro texto2"})







new Maker().Ephoto360("https://en.ephoto360.com/create-logo-avatar-mascot-style-364.html", [`${texto}`, `${texto2}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/wingeffect', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().Ephoto360("https://en.ephoto360.com/the-effect-of-galaxy-angel-wings-289.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/angelglx', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().Ephoto360("https://en.ephoto360.com/wings-galaxy-206.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/gizquadro', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().Ephoto360("https://en.ephoto360.com/writing-chalk-on-the-blackboard-30.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
}) 

app.get('/api/blackpink', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().Ephoto360("https://en.ephoto360.com/create-a-blackpink-neon-logo-text-effect-online-710.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/girlmascote', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})







new Maker().Ephoto360("https://en.ephoto360.com/create-cute-girl-gamer-mascot-logo-online-687.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/logogame', async(req, res, next) => {
texto = req.query.texto;
if(!texto) return res.json({resultado: "Cade o parametro texto"})







new Maker().Ephoto360("https://en.ephoto360.com/create-logo-team-logo-gaming-assassin-style-574.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/romantic', async(req, res, next) => {
texto = req.query.texto;
if(!texto) return res.json({resultado: "Cade o parametro texto"})







new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/romantic-messages-for-your-loved-one-391.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/fire', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/realistic-flaming-text-effect-online-197.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/smoke', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/other-design/create-an-easy-smoke-type-effect-390.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/papel', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/write-text-on-burn-paper-388.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/narutologo', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/manga-and-anime/make-naruto-banner-online-free-378.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/lovemsg', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/create-a-picture-of-love-resultado-377.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/lovemsg2', async(req, res, next) => {
texto = req.query.texto;






if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/make-quotes-under-grass-376.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/lovemsg3', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/love-text-effect-372.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/coffecup', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/put-any-text-in-to-coffee-cup-371.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/coffecup2', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/put-your-text-on-a-coffee-cup--174.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/florwooden', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/writing-on-wooden-boards-368.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/madeira', async(req, res, next) => {
texto = req.query.texto;
if(!texto) return res.json({resultado: "Cade o parametro texto"})







new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/carved-wood-effect-online-171.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/gameplay', async(req, res, next) => {
texto = req.query.texto;
texto2 = req.query.texto2;
if(!texto) return res.json({resultado: "Cade o parametro texto"})
if(!texto2) return res.json({resultado: "Cade o parametro texto2"})







new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/8-bit-text-on-arcade-rift-175.html", [`${texto}`, `${texto2}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/googlesg', async(req, res, next) => {
texto = req.query.texto;
texto2 = req.query.texto2;
texto3 = req.query.texto3;
if(!texto) return res.json({resultado: "Cade o parametro texto"})
if(!texto2) return res.json({resultado: "Cade o parametro texto2"})
if(!texto3) return res.json({resultado: "Cade o parametro texto3"})







new Maker().PhotoOxy("https://photooxy.com/other-design/make-google-suggestion-photos-238.html", [`${texto}`, `${texto2}`, `${texto3}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/neon2', async(req, res, next) => {
texto = req.query.texto;
if(!texto) return res.json({resultado: "Cade o parametro texto"})







new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/illuminated-metallic-effect-177.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/lobometal', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/create-a-wolf-metal-text-effect-365.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/harryp', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/create-harry-potter-text-on-horror-background-178.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/cup', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/put-text-on-the-cup-387.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/txtborboleta', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/butterfly-text-with-reflection-effect-183.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/shadow', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/shadow-text-effect-in-the-sky-394.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/cemiterio', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/text-on-scary-cemetery-gate-172.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/metalgold', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/other-design/create-metallic-text-glow-online-188.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/efeitoneon', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({resultado: "Cade o parametro texto"})
new Maker().PhotoOxy("https://photooxy.com/logo-and-text-effects/make-smoky-neon-glow-effect-343.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/transformer', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})
mumaker.textpro("https://textpro.me/create-a-transformer-text-effect-online-1035.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/3dstone', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})
mumaker.textpro("https://textpro.me/3d-stone-cracked-cool-text-effect-1029.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/fiction', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})
mumaker.textpro("https://textpro.me/create-science-fiction-text-effect-online-free-1038.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/cattxt', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})
mumaker.textpro("https://textpro.me/write-text-on-foggy-window-online-free-1015.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/neondevil', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})
mumaker.textpro("https://textpro.me/create-neon-devil-wings-text-effect-online-free-1014.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/demonfire', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})
mumaker.textpro("https://textpro.me/create-a-magma-hot-text-effect-online-1030.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/colaq', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/create-3d-glue-text-effect-with-realistic-style-986.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/luxury', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/3d-luxury-gold-text-effect-online-1003.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/berry', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/create-berry-text-effect-online-free-1033.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/matrix', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/matrix-style-text-effect-online-884.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/horror', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/horror-blood-text-effect-online-883.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/nuvem', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/create-a-cloud-text-effect-on-the-sky-online-1004.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/neon3', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/create-a-futuristic-technology-neon-light-text-effect-1006.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/neve', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/xmas-cards-3d-online-942.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/areia', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/write-in-sand-summer-beach-free-online-991.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/vidro', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/dropwater-text-effect-872.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/style', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/1917-style-text-effect-online-980.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/blood', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/blood-text-on-the-frosted-glass-941.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/pink', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/holographic-3d-text-effect-975.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/carbon', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/glossy-carbon-text-effect-965.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/metalblue', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/glossy-blue-metal-text-effect-967.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/jeans', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/denim-text-effect-online-919.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/jokerlogo', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/create-logo-joker-online-934.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/natal', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/create-a-christmas-holiday-snow-text-effect-1007.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/ossos', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/skeleton-text-effect-online-929.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/asfalto', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/road-warning-text-effect-878.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/break', async(req, res, next) => {
texto = req.query.texto;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/break-wall-text-effect-871.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/glitch2', async(req, res, next) => {
texto = req.query.texto;








if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})

mumaker.textpro("https://textpro.me/create-impressive-glitch-text-effects-online-1027.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/glitch', async(req, res, next) => {
texto = req.query.texto;
texto2 = req.query.texto2;







if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})
if(!texto2) return res.json({status:false,resultado:'cade o parametro texto2'})

mumaker.textpro("https://textpro.me/create-glitch-text-effect-style-tik-tok-983.html", [`${texto}`, `${texto2}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})


app.get('/api/lapis', async(req, res) => {
texto = req.query.texto;







mumaker.textpro("https://textpro.me/create-a-sketch-text-effect-online-1044.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/3dgold', async(req, res) => {
texto = req.query.texto;







mumaker.textpro("https://textpro.me/3d-golden-ancient-text-effect-online-free-1060.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/halloween', async(req, res) => {
texto = req.query.texto;







mumaker.textpro("https://textpro.me/halloween-fire-text-effect-940.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/lava', async(req, res) => {
texto = req.query.texto;







mumaker.textpro("https://textpro.me/lava-text-effect-online-914.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/toxic', async(req, res) => {
texto = req.query.texto;







mumaker.textpro("https://textpro.me/toxic-text-effect-online-901.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/demongreen', async(req, res) => {
texto = req.query.texto;







mumaker.textpro("https://textpro.me/create-green-horror-style-text-effect-online-1036.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/metalfire', async(req, res) => {
texto = req.query.texto;






mumaker.textpro("https://textpro.me/hot-metal-text-effect-843.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/thunder', async(req, res) => {
texto = req.query.texto;







mumaker.textpro("https://textpro.me/create-thunder-text-effect-online-881.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/thunderv2', async(req, res) => {
texto = req.query.texto;







mumaker.textpro("https://textpro.me/online-thunder-text-effect-generator-1031.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/neongreen', async(req, res) => {
texto = req.query.texto;







mumaker.textpro("https://textpro.me/green-neon-text-effect-874.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/neon', async(req, res) => {
texto = req.query.texto;







mumaker.textpro("https://textpro.me/neon-light-text-effect-with-galaxy-style-981.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/neon1', async(req, res) => {
texto = req.query.texto;







mumaker.textpro("https://textpro.me/free-advanced-glow-text-effect-873.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/neon3d', async(req, res) => {
texto = req.query.texto;







mumaker.textpro("https://textpro.me/create-3d-neon-light-text-effect-online-1028.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/rainbow', async(req, res) => {
texto = req.query.texto;







mumaker.textpro("https://textpro.me/3d-rainbow-color-calligraphy-text-effect-1049.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

app.get('/api/gelo', async(req, res) => {
texto = req.query.texto;







mumaker.textpro("https://textpro.me/ice-cold-text-effect-862.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})})
.catch((err) =>
console.log("ERROR"));
})

// FIM LOGOS


app.get('/api/marvel', async (req, res, next) => {
texto = req.query.texto;
texto2 = req.query.texto2;







mumaker.textpro("https://textpro.me/create-3d-avengers-logo-online-974.html", [`${texto}`,`${texto2}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/pornhub', async(req, res, next) => {
texto = req.query.texto;
texto2 = req.query.texto2;
mumaker.textpro("https://textpro.me/pornhub-style-logo-online-generator-free-977.html", [`${texto}`,`${texto2}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/space',  async(req, res, next) => {
texto = req.query.texto;
texto2 = req.query.texto2;

if(!texto) return res.json({status:false,resultado:'cade o parametro texto'})
if(!texto2) return res.json({status:false,resultado:'cade o parametro texto2'})
mumaker.textpro("https://textpro.me/create-space-3d-text-effect-online-985.html", [`${texto}`,`${texto2}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/stone', async(req, res, next) => {
texto = req.query.texto;
texto2 = req.query.texto2;







mumaker.textpro("https://textpro.me/create-a-stone-text-effect-online-982.html", [`${texto}`,`${texto2}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/steel', async(req, res, next) => {
texto = req.query.texto;
texto2 = req.query.texto2;

mumaker.textpro("https://textpro.me/3d-steel-text-effect-877.html", [`${texto}`,`${texto2}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/grafity', async(req, res, next) => {
texto = req.query.texto;
texto2 = req.query.texto2;







mumaker.textpro("https://textpro.me/create-a-cool-graffiti-text-on-the-wall-1010.html", [`${texto}`,`${texto2}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/glitch3', async(req, res, next) => {
texto = req.query.texto;
texto2 = req.query.texto2;







mumaker.textpro("https://textpro.me/create-a-glitch-text-effect-online-free-1026.html", [`${texto}`,`${texto2}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/america', async(req, res, next) => {
texto = req.query.texto;
texto2 = req.query.texto2;







mumaker.textpro("https://textpro.me/create-a-captain-america-text-effect-free-online-1039.html", [`${texto}`,`${texto2}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/angelwing', async(req, res, next) => {
texto = req.query.texto;

if(!texto) return res.json({resultado: "Cade o parametro texto"})
if(!apikey)return res.json({status:false,resultado:'cade o parametro apikey'})
if(!key.includes(apikey))return res.json({status:false,resultado:'✖️ Apikey Inválida - Entre em contato com o proprietário para solucionar o problema ou registrar sua apikey.'})
new Maker().Ephoto360("https://en.ephoto360.com/create-colorful-angel-wing-avatars-731.html", [`${texto}`])
.then((data) => { res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: data
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/about',(req, res) => {
res.json({
status:true,
dono:'@VNCSCODE - 73999197974',
resultado:'Projeto em beta'
})
})

app.get('/api/antiporno',async (req,res,next) => {
	






url = req.query.url
if(!url)return res.json({
status:false,
motivo:'nao_tem_url'
})
(`https://nsfw-demo.sashido.io/api/image/classify?url=${url}`).then(e => {
res.json(e)
})
})

router.all('/api/twitter', async (req, res) => {







url = req.query.url
if(!url)return res.json({
status:false,
motivo:'Cadê o parâmetro url?'
})
auu = await fetchJson(`https://ayu.p7api.xyz/api/dl/twitter?link=${url}&apikey=6bb2f5-22a158-0441f9-6b4308-115f0f`)
res.json({
status: true,
resultado: "💞ZERO TWO RESET API'S - MELHOR SITE DE APIS💞",
criador: `${criador}`,
resultado: {
descrição: `${auu.resultado.descrição}`,
capa: `${auu.resultado.capa}`,
HD: `${auu.resultado.HD}`,
SD: `${auu.resultado.SD}`,
audio: `${auu.resultado.audio}`,
}
})
})  

app.get('/api/rastreio', async (req, res, next) => {
q = req.query.q
if(!q)return res.json({status:false, motivo:'Cadê o parâmetro q?'})







const { rastrear } = require('./modulos-api/apis.js')
rastrear(q).then(resultado => {
res.json(resultado)
}).catch(error => {
console.log(error);
res.status(500).send({
status: 500,
resultado: 'Erro no Servidor Interno'
})
});
})
 

app.get('/api/consultas/bank', async (req, res) => {
query = req.query.query
if(!query)return res.json({status:false,resultado:'Cade o parametro query??'})







try {
auu = await fetchJson(`https://brasilapi.com.br/api/banks/v1/${query}`)
let resultadobank = `*👤 ISPB:* ${auu.ispb}\n*🏦 BANCO:* ${auu.name}\n*🏧 CODE:* ${auu.code}\n*👤 FULL NAME:* ${auu.fullName}`
res.json({
status: true,
resultado: "💞ZERO TWO RESET API'S - MELHOR SITE DE APIS💞",
criador: `${criador}`,
resultado: `${resultadobank}`,
})
} catch (error) {
return res.status(404).json({ resultado: "Banco De Dados Está Sendo Atualizado Agora - Consulte Novamente em [1 Minuto]", status: 500 });
}
})
 
app.get('/api/consultas/bin', async (req, res) => {
query = req.query.query
if(!query)return res.json({status:false, resultado:'Cade o parametro query??'})







try {
auu = await fetchJson(`https://teddyapis.teddymodz.repl.co/bin.php?bin=${query}`)
res.json({
status: true,
resultado: "💞ZERO TWO RESET API'S - MELHOR SITE DE APIS💞",
criador: `${criador}`,
resultado: `*💳 BIN:* ${auu.dados.bin}\n*✅ PAIS:* ${auu.dados.pais}\n*🚩 BANDEIRA:* ${auu.dados.bandeira}\n*🅰️ TIPO:* ${auu.dados.tipo}*📊 NIVEL:* ${auu.dados.nivel}\n*🏦 BANCO:* ${auu.dados.banco}`,
})
} catch (error) {
return res.status(404).json({ resultado: "Banco De Dados Está Sendo Atualizado Agora - Consulte Novamente em [1 Minuto]", status: 500 });
}
})

app.get('/api/check-number', async (req, res) => {
query = req.query.query
if(!query)return res.json({status:false, resultado:'Cade o parametro query??'})







try {
anu = await fetchJson(`http://apilayer.net/api/validate?access_key=d57f91cf25db296a9e223888cfdc064a&number=${query}`)
res.json({
status: true, 
resultado: "💞ZERO TWO RESET API'S - MELHOR SITE DE APIS💞",
criador: `${criador}`,
resultado: {
number: anu.number, 
local_format: anu.local_format ,
international_format: anu.international_format,
country_prefix: anu.country_prefix,
country_code: anu.country_code,
country_name: anu.country_name, 
location: anu.location,
carrier: anu.carrier,
line_type: anu.line_type, 
}
})
} catch (error) {
return res.status(404).json({ resultado: `${msgerro}`, status: 500 });
}
})

app.get('/api/wikipedia', async (req, res) => {
q = req.query.q
if(!q)return res.json({
status:false,
resultado:'Cade o parametro q??'
})







wikip = await axios.get(`https://pt.wikipedia.org/w/api.php?action=query&format=json&list=search&srsearch=${encodeURIComponent(q)}&prop=info&inprop=url`);
wikis = await axios.get(`https://pt.wikipedia.org/w/api.php?format=json&action=query&prop=extracts&exintro&explaintext&redirects=1&pageids=${wikip.data.query.search[0].pageid}`);
res.json({
status: true,
resultado: "💞ZERO TWO RESET API'S - MELHOR SITE DE APIS💞",
criador: `${criador}`,
resultado: `${wikis.data.query.pages[Object.keys(wikis.data.query.pages)].extract}`,
}) 
}) 


app.get('/api/n', async (req, res) => {
query = req.query.query 
if(!query)return res.json({status:false, resultado:'Cade o parametro query??'})







anu = await fetchJson(`http://apilayer.net/api/validate?access_key=d57f91cf25db296a9e223888cfdc064a&number=${query}`)
var FomartN = query.substring(2);
var pro = await fetchJson(`https://apisdedicado.nexos.dev/SerasaTelefones/telefone?token=2ae274ad75c45b657547631a82358dbc&telefone=${FomartN}`)
res.json({
status: true, 
resultado: {
number: anu.number,

country: anu.country_name, 
location: anu.location,
dispositivo: anu.line_type, 
}})})

app.get("/datasave", async (req, res) => {
consulta = req.query.consulta
if(!consulta)return res.json({
status:false,
resultado:'insira o tipo de consulta'
})    
res.sendFile(bla + `/consultas/${consulta}.txt`);
})

app.get('/api/onlyfans/videos', async (req, res, next) => {






	
try {
var onlyNumber = `${Math.floor(Math.random() * 157)}`
var hasil = fs.readFileSync(`./data/VideosRandomOnlyFans/1 (${onlyNumber}).mp4`);
var { upload } = require('./modulos-api/tourl');
var resultados = await upload(hasil)
res.json({
status: true,
resultado: "💞ZERO TWO RESET API'S - MELHOR SITE DE APIS💞",
criador: `${criador}`,
resultado: `${resultados}`,
})
var data = [];
if (fs.existsSync('./data/SaveOnlyFans/Videos.json')) {
    const jsonContent = fs.readFileSync('./data/SaveOnlyFans/Videos.json', 'utf-8');
    data = JSON.parse(jsonContent);
}
data = [...data, resultados];
fs.writeFileSync('./data/SaveOnlyFans/Videos.json', JSON.stringify(data, null, 4));
} catch (e) {
return res.json({resultado: `${e}`})
} 
})  
  
app.get('/api/onlyfans/fotos', async (req, res, next) => {







try { 
var onlyNumber = `${Math.floor(Math.random() * 396)}`
var hasil = fs.readFileSync(`./data/FotosRandomOnlyFans/1 (${onlyNumber}).jpg`)
var { upload } = require('./modulos-api/tourl');
var resultados = await upload(hasil)
res.json({
status: true,
resultado: "💞ZERO TWO RESET API'S - MELHOR SITE DE APIS💞",
criador: `${criador}`,
resultado: `${resultados}`,
})
} catch (e) {
return res.json({resultado: `${e}`})
}
})

app.get('/sticker/figu_emoji', async (req, res, next) => {







	if(key.includes(apikey)){    
var rnd = Math.floor(Math.random() * 102)
    hasil = `https://raw.githubusercontent.com/Scheyot2/sakura-botv6/main/FIGURINHAS/Figurinha-emoji/${rnd}.webp`
	  data = await fetch(hasil).then(v => v.buffer())   
         await fs.writeFileSync('/tmp/stickera.webp', data)
        res.sendFile('/tmp/stickera.webp')
         } else {
  res.json({resultado: `${msgerro}`})
}    
})

app.get('/sticker/figu_flork', async (req, res, next) => {







	if(key.includes(apikey)){    
var rnd = Math.floor(Math.random() * 102)
    hasil = `https://raw.githubusercontent.com/Scheyot2/anya-bot/main/Figurinhas/figu_flork/${rnd}.webp`
	  data = await fetch(hasil).then(v => v.buffer())   
         await fs.writeFileSync('/tmp/stickera.webp', data)
        res.sendFile('/tmp/stickera.webp')
         } else {
  res.json({resultado: `${msgerro}`})
}    
}) 
 
app.get('/teste', async (req, res, next) => {
const { MonsterApiClient } = require('monsterapi') 
var client = new MonsterApiClient('eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VybmFtZSI6IjAwM2JmODcxN2FlZGUxNDRkOWJkYWUwZTU2Y2Q0YWZmIiwiY3JlYXRlZF9hdCI6IjIwMjMtMTAtMDlUMDM6NTE6MjMuNDA4MTcyIn0.Wr-wQyQOKhDgtPxTSUWZD9UkVVBnJLTGTr2syf_WZdw');
var model = 'whisper'; // Replace with a valid model name
var input = 'Olá';
client.generate(model, input)
  .then((response) => {
    // Handle the response from the API
    console.log('Generated content:', response);
  })
  .catch((error) => {
    // Handle API errors
    console.error('Error:', error);
  });
})

app.get('/sticker/figurinhas_ale', async (req, res, next) => {







	if(key.includes(apikey)){    
var rnd = Math.floor(Math.random() * 8051)
    hasil = `https://raw.githubusercontent.com/badDevelopper/Testfigu/main/fig (${rnd}).webp`
	  data = await fetch(hasil).then(v => v.buffer())   
         await fs.writeFileSync('/tmp/stickera.webp', data)
        res.sendFile('/tmp/stickera.webp')
         } else {
  res.json({resultado: `${msgerro}`})
}    
}) 


app.get('/ias/gemini', async (req, res) => {
q = req.query.q
if(!q)return res.json({status:false,INVALIDA:'Cade o parametro q??'})







const { init, askAI, Chat } = require("gemini-ai")
await init("fAhvY2_mk7qbQu_TBpVdAbwfxHAacCRfAgjZyZNOs_74Eh9sYpnftf_2kU-fkNtAdnmq0A.")
response = await askAI(q)
res.json({
status: true,
resultado: "💞ZERO TWO RESET API'S - MELHOR SITE DE APIS💞",
criador: `${criador}`,
resultado: response,
})
})

app.get("/ias/bing", async(req, res) => {
try {







var pesquisa = req.query.pesquisa
if (!pesquisa) return res.json({resultado: "Cade, quer pesquisar o que?"})
const url = `https://www.bing.com/search?q=${pesquisa}&setmkt=pt-BR&PC=EMMX01&form=LWS002&scope=web`;
axios(url).then(response => {
const $ = cheerio.load(response.data);
const Rst = [];
$("div > p").each(function(){
const TTL = $(this).text();
if(TTL.length > 10)
Rst.push({ 
TTL
});
});
let bla = ''
for (let i of Rst) {
bla += `${i.TTL.replace(new RegExp("Web", "gi"), "")}\n\n`
}
res.json({
dono: 'VNCSCODE',
resultado: bla
})
}).catch(e => {
return res.json({resultado: "Error, digite algo que queira pesquisar.."})
})
} catch (e) {
return res.json({resultado: `${msgerro}`})
}
})


app.get("/ias/gpt", async(req, res, next) => {
async function PRGT() {
try {
var { Configuration, OpenAIApi } = require("openai") //precisa baixar o módulo (npm i openai)
var { q, apikey, tokengpt } = req.query
var configopen = new Configuration({ apiKey: tokengpt.trim() }); //coloca sua key aqui
 var openai = new OpenAIApi(configopen); //configuração do openai (sincronização da sua key)
 if(!q) return res.json({resultado: 'Em que posso te ajudar?, pergunte e eu te responderei 🙂'})
 if(!tokengpt) return res.json({resultado: `Faltando definir o token: &tokengpt=org-WVsOFQuRyxRNrOJ8thAkAnVp`})
 var resopen = await openai.createCompletion({
frequency_penalty: 0.5, //não sei
max_tokens: 3000, //quantidade máxima de palavra-chave
model: "text-davinci-003", //modelo de respostas
presence_penalty: 0, //não sei
prompt: q, //o que deseja  
temperature: 1, //respostas exatas (não entendi muito bem na documentação)
top_p: 1, //não sei
});
respgpt = resopen.data.choices[0].text.includes('\n') ? resopen.data.choices[0].text.replace('\n\n', '') : resopen.data.choices[0].text
res.json({resposta: respgpt})
} catch (e) {
console.log(e)
res.json({resposta: `${msgerro}`})
}
}
PRGT().catch(async(e) => {
console.log(e)
res.json({resposta: `${msgerro}`})
})
})

app.get("/ias/super_img", async(req, res, next) => {
async function PRGT2() {
try {
var { Configuration, OpenAIApi } = require("openai") //precisa baixar o módulo (npm i openai)
var { q, apikey, tokengpt } = req.query
var configopen = new Configuration({ apiKey: tokengpt.trim()}); //coloca sua key aqui
var openai = new OpenAIApi(configopen); //configuração do openai (sincronização da sua key)
 if(!q) return res.json({resultado: 'Em que posso te ajudar?, peça algo, como: hulk com raiva 🙂'})
if(!tokengpt) return res.json({resultado: `Faltando definir o token: &tokengpt=org-WVsOFQuRyxRNrOJ8thAkAnVp`})
 var respimg = await openai.createImage({
 prompt: q, //o que deseja
 n: 1, //quantidade de imagem
 size: "1024x1024", //tamanho (aceita apenas: 256x256, 512x512, e 1024x1024)
 });
res.type("jpeg")
res.send(await getBuffer(respimg.data.data[0].url))
} catch {
return res.json({resposta: "Seu token expirou mano!!"})
}
}
PRGT2().catch(async() => {
return res.json({resposta: "Seu token expirou mano!!"})
})
})

app.get('/ias/animeai', async (req, res, next) => {
 var img = req.query.img
if(!img)return res.json({status:false,motivo:'Cadê o parâmetro img?'})
try {
    hasil = `http://api.lolhuman.xyz/api/imagetoanime?apikey=GataDios&img=${img}`
	  data = await fetch(hasil).then(v => v.buffer())   
         await fs.writeFileSync(bla+'/tmp/gostosinha.jpg', data)
        res.sendFile(bla+'/tmp/gostosinha.jpg') 
		} catch (error) {
return res.status(404).json({ resultado: `${msgerro}`, status: 500 });
}
}) 

app.get('/imagem/qrcode', async (req, res, next) => {
var texto = req.query.texto
if(!texto)return res.json({status:false,motivo:'Cadê o parâmetro texto?'})







try {
    hasil = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${texto}`
	  data = await fetch(hasil).then(v => v.buffer())   
         await fs.writeFileSync(bla+'/tmp/gostosinha.jpg', data)
        res.sendFile(bla+'/tmp/gostosinha.jpg') 
} catch (error) {
return res.status(404).json({ resultado: `${msgerro}`, status: 500 });
}
}) 

app.get('/api/attp', async (req, res, next) => {
      var texto = req.query.texto
if(!texto)return res.json({status:false,motivo:'Cadê o parâmetro img?'})
    hasil = `http://br3.bronxyshost.com:3039/api-bronxys/attp?texto=${texto}&apikey=daniel_dzn`
	  data = await fetch(hasil).then(v => v.buffer())   
         await fs.writeFileSync(bla+'/tmp/gostosinha.jpg', data)
        res.sendFile(bla+'/tmp/gostosinha.jpg') 
}) 
 

app.get('/api/attp1', async (req, res, next) => {
	






      var texto = req.query.texto
if(!texto)return res.json({status:false,motivo:'Cadê o parâmetro texto?'})
    hasil = `https://marcos025.onrender.com/api/maker/attp1?texto=${texto}&apikey=XANAX-VNCS$`
	  data = await fetch(hasil).then(v => v.buffer())   
         await fs.writeFileSync(bla+'/tmp/gostosinha.jpg', data)
        res.sendFile(bla+'/tmp/gostosinha.jpg') 
}) 

app.get('/api/attp2', async (req, res, next) => {   
      var texto = req.query.texto
if(!texto)return res.json({status:false,motivo:'Cadê o parâmetro texto?'})
   






    hasil = `https://marcos025.onrender.com/api/maker/attp2?texto=${texto}&apikey=XANAX-VNCS$`
	  data = await fetch(hasil).then(v => v.buffer())   
         await fs.writeFileSync(bla+'/tmp/gostosinha.jpg', data)
        res.sendFile(bla+'/tmp/gostosinha.jpg') 
}) 


app.get('/api/attp3', async (req, res, next) => {
      var texto = req.query.texto
if(!texto)return res.json({status:false,motivo:'Cadê o parâmetro texto?'})
 





  
    hasil = `https://marcos025.onrender.com/api/maker/attp3?texto=${texto}&apikey=XANAX-VNCS$`
	  data = await fetch(hasil).then(v => v.buffer())   
         await fs.writeFileSync(bla+'/tmp/gostosinha.jpg', data)
        res.sendFile(bla+'/tmp/gostosinha.jpg') 
}) 

app.get('/api/attp4', async (req, res, next) => {







      var texto = req.query.texto
if(!texto)return res.json({status:false,motivo:'Cadê o parâmetro texto?'})
    hasil = `https://marcos025.onrender.com/api/maker/attp4?texto=${texto}&apikey=XANAX-VNCS$`
	  data = await fetch(hasil).then(v => v.buffer())   
         await fs.writeFileSync(bla+'/tmp/gostosinha.jpg', data)
        res.sendFile(bla+'/tmp/gostosinha.jpg') 
}) 


app.get('/api/attp5', async (req, res, next) => {
      var texto = req.query.texto
if(!texto)return res.json({status:false,motivo:'Cadê o parâmetro texto?'})
   






    hasil = `https://marcos025.onrender.com/api/maker/attp5?texto=${texto}&apikey=XANAX-VNCS$`
	  data = await fetch(hasil).then(v => v.buffer())   
         await fs.writeFileSync(bla+'/tmp/gostosinha.jpg', data)
        res.sendFile(bla+'/tmp/gostosinha.jpg') 
}) 


app.get('/api/attp6', async (req, res, next) => {
var texto = req.query.texto 
if(!texto)return res.json({status:false,motivo:'Cadê o parâmetro texto?'})







    hasil = `https://marcos025.onrender.com/api/maker/attp6?texto=${texto}&apikey=XANAX-VNCS$`
	  data = await fetch(hasil).then(v => v.buffer())   
         await fs.writeFileSync(bla+'/tmp/gostosinha.jpg', data)
        res.sendFile(bla+'/tmp/gostosinha.jpg') 
}) 


app.get('/api/shitpost', (req, res) => {
(async() => {







data = fs.readFileSync('./modulos-api/shitpost.js');
jsonData = JSON.parse(data);
randIndex = Math.floor(Math.random() * jsonData.length);
randKey = jsonData[randIndex];
data = await getBuffer(randKey.result)
await fs.writeFileSync(bla+'/tmp/gostosinha.jpg', data)
        res.sendFile(bla+'/tmp/gostosinha.jpg') 
})()
})

app.get('/sticker/figu_anime', async (req, res, next) => {







	if(key.includes(apikey)){    
var rnd = Math.floor(Math.random() * 109)
    hasil = `https://raw.githubusercontent.com/Scheyot2/sakura-botv6/main/FIGURINHAS/figurinha-anime/${rnd}.webp`
	  data = await fetch(hasil).then(v => v.buffer())   
         await fs.writeFileSync('/tmp/stickera.webp', data)
        res.sendFile('/tmp/stickera.webp')
         } else {
  res.json({resultado: `${msgerro}`})
}    
})


app.get('/api/mirellapng', async (req, res, next) => {







	if(key.includes(apikey)){    
    hasil = `https://apirest.gestorvip.com/api/mirellapng?apikey=Toms123`
	  data = await fetch(hasil).then(v => v.buffer())   
         await fs.writeFileSync('/tmp/asupan.png', data)
        res.sendFile('/tmp/asupan.png')
         } else {
  res.json({resultado: `${msgerro}`})
}    
})

app.get('/nsfw/ahegao', async (req, res, next) => {
      






	   
    const ahegao = JSON.parse(fs.readFileSync(bla + '/data/ahegao.json'));
    const randahegao = ahegao[Math.floor(Math.random() * ahegao.length)];
    data = await fetch(randahegao).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/ahegao.jpeg', data)
    res.sendFile(bla + '/tmp/ahegao.jpeg')
 
})

app.get('/nsfw/ass', async (req, res, next) => {
	






	   
    const ass = JSON.parse(fs.readFileSync(bla + '/data/ass.json'));
    const randass = ass[Math.floor(Math.random() * ass.length)];
    data = await fetch(randass).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/ass.jpeg', data)
    res.sendFile(bla + '/tmp/ass.jpeg')
 
})

app.get('/nsfw/bdsm', async (req, res, next) => {
	






	   
    const bdsm = JSON.parse(fs.readFileSync(bla + '/data/bdsm.json'));
    const randbdsm = bdsm[Math.floor(Math.random() * bdsm.length)];
    data = await fetch(randbdsm).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/bdsm.jpeg', data)
    res.sendFile(bla + '/tmp/bdsm.jpeg')
 
})

app.get('/nsfw/blowjob', async (req, res, next) => {
  






    const blowjob = JSON.parse(fs.readFileSync(bla + '/data/blowjob.json'));
    const randblowjob = blowjob[Math.floor(Math.random() * blowjob.length)];
    data = await fetch(randblowjob).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/blowjob.jpeg', data)
    res.sendFile(bla + '/tmp/blowjob.jpeg')
})

app.get('/nsfw/cuckold', async (req, res, next) => {







	   
    const cuckold = JSON.parse(fs.readFileSync(bla + '/data/cuckold.json'));
    const randcuckold = cuckold[Math.floor(Math.random() * cuckold.length)];
    data = await fetch(randcuckold).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/cuckold.jpeg', data)
    res.sendFile(bla + '/tmp/cuckold.jpeg')
 
})

app.get('/nsfw/cum', async (req, res, next) => {






		
    const cum = JSON.parse(fs.readFileSync(bla + '/data/cum.json'));
    const randcum = cum[Math.floor(Math.random() * cum.length)];
    data = await fetch(randcum).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/cum.jpeg', data)
    res.sendFile(bla + '/tmp/cum.jpeg')
})

app.get('/nsfw/ero', async (req, res, next) => {
      






    const ero = JSON.parse(fs.readFileSync(bla + '/data/ero.json'));
    const randero = ero[Math.floor(Math.random() * ero.length)];
    data = await fetch(randero).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/ero.jpeg', data)
    res.sendFile(bla + '/tmp/ero.jpeg')
})

app.get('/nsfw/femdom', async (req, res, next) => {
      






	   
    const femdom = JSON.parse(fs.readFileSync(bla + '/data/femdom.json'));
    const randfemdom = femdom[Math.floor(Math.random() * femdom.length)];
    data = await fetch(randfemdom).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/femdom.jpeg', data)
    res.sendFile(bla + '/tmp/femdom.jpeg')
 
})

app.get('/nsfw/foot', async (req, res, next) => {
      





 
    const foot = JSON.parse(fs.readFileSync(bla + '/data/foot.json'));
    const randfoot = foot[Math.floor(Math.random() * foot.length)];
    data = await fetch(randfoot).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/foot.jpeg', data)
    res.sendFile(bla + '/tmp/foot.jpeg')
})

app.get('/nsfw/gangbang', async (req, res, next) => {
      






    const gangbang = JSON.parse(fs.readFileSync(bla + '/data/gangbang.json'));
    const randgangbang = gangbang[Math.floor(Math.random() * gangbang.length)];
    data = await fetch(randgangbang).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/gangbang.jpg', data)
    res.sendFile(bla + '/tmp/gangbang.jpg')
 
})

app.get('/nsfw/glasses', async (req, res, next) => {
      






	   
    const glasses = JSON.parse(fs.readFileSync(bla + '/data/glasses.json'));
    const randglasses = glasses[Math.floor(Math.random() * glasses.length)];
    data = await fetch(randglasses).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/glasses.jpeg', data)
    res.sendFile(bla + '/tmp/glasses.jpeg')
 
})

app.get('/nsfw/hentai', async (req, res, next) => {
      






	   
    const hentai = JSON.parse(fs.readFileSync(bla + '/data/hentai.json'));
    const randhentai = hentai[Math.floor(Math.random() * hentai.length)];
    data = await fetch(randhentai).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/hentai.jpeg', data)
    res.sendFile(bla + '/tmp/hentai.jpeg')
 
})

app.get('/nsfw/gifs', async (req, res, next) => {
      






	   
    const gifs = JSON.parse(fs.readFileSync(bla + '/data/gifs.json'));
    const randgifs = gifs[Math.floor(Math.random() * gifs.length)];
    data = await fetch(randgifs).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/gifs.jpeg', data)
    res.sendFile(bla + '/tmp/gifs.jpeg')
 
})

app.get('/figu', async (req, res, next) => {
      






	   
    const gifs = JSON.parse(fs.readFileSync(bla + '/lib/figurinhas.json'));
    const randgifs = gifs[Math.floor(Math.random() * gifs.length)];
    data = await fetch(randgifs).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/stickera.webp', data)
    res.sendFile(bla + '/tmp/stickera.webp')
 
})

app.get('/api/stickera', async (req, res, next) => {
      






	   
    const gifs = JSON.parse(fs.readFileSync(bla + '/lib/figurinhas.json'));
    const randgifs = gifs[Math.floor(Math.random() * gifs.length)];
    data = await fetch(randgifs).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/stickera.webp', data)
    res.sendFile(bla + '/tmp/stickera.webp')
 
})

app.get('/nsfw/jahy', async (req, res, next) => {
      






	   
    const jahy = JSON.parse(fs.readFileSync(bla + '/data/jahy.json'));
    const randjahy = jahy[Math.floor(Math.random() * jahy.length)];
    data = await fetch(randjahy).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/jahy.jpeg', data)
    res.sendFile(bla + '/tmp/jahy.jpeg')
 
})

app.get('/nsfw/manga', async (req, res, next) => {
      






	   
    const manga = JSON.parse(fs.readFileSync(bla + '/data/manga.json'));
    const randmanga = manga[Math.floor(Math.random() * manga.length)];
    data = await fetch(randmanga).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/manga.jpeg', data)
    res.sendFile(bla + '/tmp/manga.jpeg')
 
})

app.get('/nsfw/masturbation', async (req, res, next) => {
      






	   
    const masturbation = JSON.parse(fs.readFileSync(bla + '/data/masturbation.json'));
    const randmasturbation = masturbation[Math.floor(Math.random() * masturbation.length)];
    data = await fetch(randmasturbation).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/masturbation.jpeg', data)
    res.sendFile(bla + '/tmp/masturbation.jpeg')
 
})

app.get('/nsfw/neko', async (req, res, next) => {
      






	   
    const neko = JSON.parse(fs.readFileSync(bla + '/data/neko.json'));
    const randneko = neko[Math.floor(Math.random() * neko.length)];
    data = await fetch(randneko).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/neko.jpeg', data)
    res.sendFile(bla + '/tmp/neko.jpeg')
 
})

app.get('/nsfw/orgy', async (req, res, next) => {
      






	   
    const orgy = JSON.parse(fs.readFileSync(bla + '/data/orgy.json'));
    const randorgy = orgy[Math.floor(Math.random() * orgy.length)];
    data = await fetch(randorgy).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/orgy.jpeg', data)
    res.sendFile(bla + '/tmp/orgy.jpeg')
 
})

app.get('/nsfw/panties', async (req, res, next) => {
      






	   
    const panties = JSON.parse(fs.readFileSync(bla + '/data/panties.json'));
    const randpanties = panties[Math.floor(Math.random() * panties.length)];
    data = await fetch(randpanties).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/panties.jpeg', data)
    res.sendFile(bla + '/tmp/panties.jpeg')
 
})

app.get('/nsfw/pussy', async (req, res, next) => {
      






	   
    const pussy = JSON.parse(fs.readFileSync(bla + '/data/pussy.json'));
    const randpussy = pussy[Math.floor(Math.random() * pussy.length)];
    data = await fetch(randpussy).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/pussy.jpeg', data)
    res.sendFile(bla + '/tmp/pussy.jpeg')
 
})

app.get('/nsfw/neko2', async (req, res, next) => {
      






	   
    const neko2 = JSON.parse(fs.readFileSync(bla + '/data/neko2.json'));
    const randneko2 = neko2[Math.floor(Math.random() * neko2.length)];
    data = await fetch(randneko2).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/neko2.jpeg', data)
    res.sendFile(bla + '/tmp/neko2.jpeg')
 
})

app.get('/nsfw/tentacles', async (req, res, next) => {
      






	   
    const tentacles = JSON.parse(fs.readFileSync(bla + '/data/tentacles.json'));
    const randtentacles = tentacles[Math.floor(Math.random() * tentacles.length)];
    data = await fetch(randtentacles).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/tentacles.jpeg', data)
    res.sendFile(bla + '/tmp/tentacles.jpeg')
 
})

app.get('/nsfw/thighs', async (req, res, next) => {
     






	   
    const thighs = JSON.parse(fs.readFileSync(bla + '/data/thighs.json'));
    const randthighs = thighs[Math.floor(Math.random() * thighs.length)];
    data = await fetch(randthighs).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/thighs.jpeg', data)
    res.sendFile(bla + '/tmp/thighs.jpeg')
 
})

app.get('/nsfw/yuri', async (req, res, next) => {
      






	   

    const yuri = JSON.parse(fs.readFileSync(bla + '/data/yuri.json'));
    const randyuri = yuri[Math.floor(Math.random() * yuri.length)];
    data = await fetch(randyuri).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/yuri.jpeg', data)
    res.sendFile(bla + '/tmp/yuri.jpeg')
 
})

app.get('/nsfw/zettai', async (req, res, next) => {
      






	   

    const zettai = JSON.parse(fs.readFileSync(bla + '/data/zettai.json'));
    const randzettai = zettai[Math.floor(Math.random() * zettai.length)];
    data = await fetch(randzettai).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/zettai.jpeg', data)
    res.sendFile(bla + '/tmp/zettai.jpeg')
 
})

app.get('/random/keneki', async (req, res, next) => {
      






	   

    const keneki = JSON.parse(fs.readFileSync(bla + '/data/keneki.json'));
    const randkeneki = keneki[Math.floor(Math.random() * keneki.length)];
    data = await fetch(randkeneki).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/keneki.jpeg', data)
    res.sendFile(bla + '/tmp/keneki.jpeg')
 
})

app.get('/random/megumin', async (req, res, next) => {
      






	   

    const megumin = JSON.parse(fs.readFileSync(bla + '/data/megumin.json'));
    const randmegumin = megumin[Math.floor(Math.random() * megumin.length)];
    data = await fetch(randmegumin).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/megumin.jpeg', data)
    res.sendFile(bla + '/tmp/megumin.jpeg')
 
})

app.get('/random/yotsuba', async (req, res, next) => {
      






	   

    const yotsuba = JSON.parse(fs.readFileSync(bla + '/data/yotsuba.json'));
    const randyotsuba = yotsuba[Math.floor(Math.random() * yotsuba.length)];
    data = await fetch(randyotsuba).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/yotsuba.jpeg', data)
    res.sendFile(bla + '/tmp/yotsuba.jpeg')
 
})

app.get('/random/shinomiya', async (req, res, next) => {
      






	   

    const shinomiya = JSON.parse(fs.readFileSync(bla + '/data/shinomiya.json'));
    const randshinomiya = shinomiya[Math.floor(Math.random() * shinomiya.length)];
    data = await fetch(randshinomiya).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/shinomiya.jpeg', data)
    res.sendFile(bla + '/tmp/shinomiya.jpeg')
 
})

app.get('/random/yumeko', async (req, res, next) => {
      






	   

    const yumeko = JSON.parse(fs.readFileSync(bla + '/data/yumeko.json'));
    const randyumeko = yumeko[Math.floor(Math.random() * yumeko.length)];
    data = await fetch(randyumeko).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/yumeko.jpeg', data)
    res.sendFile(bla + '/tmp/yumeko.jpeg')
 
})

app.get('/random/tejina', async (req, res, next) => {
      






const tejina = JSON.parse(fs.readFileSync(bla + '/data/tejina.json'));
    const randtejina = tejina[Math.floor(Math.random() * tejina.length)];
    data = await fetch(randtejina).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/tejina.jpeg', data)
    res.sendFile(bla + '/tmp/tejina.jpeg')
})

app.get('/random/chiho', async (req, res, next) => {
      






const chiho = JSON.parse(fs.readFileSync(bla + '/data/chiho.json'));
    const randchiho = chiho[Math.floor(Math.random() * chiho.length)];
    data = await fetch(randchiho).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/chiho.jpeg', data)
    res.sendFile(bla + '/tmp/chiho.jpeg')
})

app.get('/wallpaper/cyberspace', async (req, res, next) => {
      






const cyberspace = JSON.parse(fs.readFileSync(bla + '/data/CyberSpace.json'));
    const randcyberspace = cyberspace[Math.floor(Math.random() * cyberspace.length)];
    data = await fetch(randcyberspace).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/cyberspace.jpeg', data)
    res.sendFile(bla + '/tmp/cyberspace.jpeg')
})

app.get('/wallpaper/gaming', async (req, res, next) => {
      






const gaming = JSON.parse(fs.readFileSync(bla + '/data/GameWallp.json'));
    const randgaming = gaming[Math.floor(Math.random() * gaming.length)];
    data = await fetch(randgaming).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/gaming.jpeg', data)
    res.sendFile(bla + '/tmp/gaming.jpeg')
})

app.get('/wallpaper/programing', async (req, res, next) => {
      






const programing = JSON.parse(fs.readFileSync(bla + '/data/Programming.json'));
    const randprograming = programing[Math.floor(Math.random() * programing.length)];
    data = await fetch(randprograming).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/programing.jpeg', data)
    res.sendFile(bla + '/tmp/programing.jpeg')
})

app.get('/wallpaper/wallpapertec', async (req, res, next) => {
      






const teknologi = JSON.parse(fs.readFileSync(bla + '/data/Technology.json'));
    const randteknologi = teknologi[Math.floor(Math.random() * teknologi.length)];
    data = await fetch(randteknologi).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/teknologi.jpeg', data)
    res.sendFile(bla + '/tmp/teknologi.jpeg') 
})

app.get('/wallpaper/mountain', async (req, res, next) => {
      






const mountain = JSON.parse(fs.readFileSync(bla + '/data/Mountain.json'));
    const randmountain = mountain[Math.floor(Math.random() * mountain.length)];
    data = await fetch(randmountain).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/mountain.jpeg', data)
    res.sendFile(bla + '/tmp/mountain.jpeg')
})



app.get('/random/toukachan', async (req, res, next) => {
      






const toukachan = JSON.parse(fs.readFileSync(bla + '/data/toukachan.json'));
    const randtoukachan = toukachan[Math.floor(Math.random() * toukachan.length)];
    data = await fetch(randtoukachan).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/toukachan.jpeg', data)
    res.sendFile(bla + '/tmp/toukachan.jpeg')
 
})

app.get('/random/akira', async (req, res, next) => {
      






const akira = JSON.parse(fs.readFileSync(bla + '/data/akira.json'));
    const randakira = akira[Math.floor(Math.random() * akira.length)];
    data = await fetch(randakira).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/akira.jpeg', data)
    res.sendFile(bla + '/tmp/akira.jpeg')
 
})

app.get('/random/itori', async (req, res, next) => {
      






const itori = JSON.parse(fs.readFileSync(bla + '/data/itori.json'));
    const randitori = itori[Math.floor(Math.random() * itori.length)];
    data = await fetch(randitori).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/itori.jpeg', data)
    res.sendFile(bla + '/tmp/itori.jpeg')
 
})

app.get('/random/kurumi', async (req, res, next) => {
      






	   

    const kurumi = JSON.parse(fs.readFileSync(bla + '/data/kurumi.json'));
    const randkurumi = kurumi[Math.floor(Math.random() * kurumi.length)];
    data = await fetch(randkurumi).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/kurumi.jpeg', data)
    res.sendFile(bla + '/tmp/kurumi.jpeg')
 
})

app.get('/random/miku', async (req, res, next) => {
      






	   

    const miku = JSON.parse(fs.readFileSync(bla + '/data/miku.json'));
    const randmiku = miku[Math.floor(Math.random() * miku.length)];
    data = await fetch(randmiku).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/miku.jpeg', data)
    res.sendFile(bla + '/tmp/miku.jpeg')
 
})

app.get('/random/pokemon', async (req, res, next) => {
      






	   

    const pokemon = JSON.parse(fs.readFileSync(bla + '/data/pokemon.json'));
    const randpokemon = pokemon[Math.floor(Math.random() * pokemon.length)];
    data = await fetch(randpokemon).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/pokemon.jpeg', data)
    res.sendFile(bla + '/tmp/pokemon.jpeg')
 
})

app.get('/random/ryujin', async (req, res, next) => {
      






	   

    const ryujin = JSON.parse(fs.readFileSync(bla + '/data/ryujin.json'));
    const randryujin = ryujin[Math.floor(Math.random() * ryujin.length)];
    data = await fetch(randryujin).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/ryujin.jpeg', data)
    res.sendFile(bla + '/tmp/ryujin.jpeg')
 
})

app.get('/random/rose', async (req, res, next) => {
      






	   const rose = JSON.parse(fs.readFileSync(bla + '/data/rose.json'));
    const randrose = rose[Math.floor(Math.random() * rose.length)];
    data = await fetch(randrose).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/rose.jpeg', data)
    res.sendFile(bla + '/tmp/rose.jpeg')
 
})

app.get('/random/kaori', async (req, res, next) => {
      






const kaori = JSON.parse(fs.readFileSync(bla + '/data/kaori.json'));
    const randkaori = kaori[Math.floor(Math.random() * kaori.length)];
    data = await fetch(randkaori).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/kaori.jpeg', data)
    res.sendFile(bla + '/tmp/kaori.jpeg')
 
})

app.get('/random/shizuka', async (req, res, next) => {
      






	   

    const shizuka = JSON.parse(fs.readFileSync(bla + '/data/shizuka.json'));
    const randshizuka = shizuka[Math.floor(Math.random() * shizuka.length)];
    data = await fetch(randshizuka).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/shizuka.jpeg', data)
    res.sendFile(bla + '/tmp/shizuka.jpeg')
 
})

app.get('/random/kaga', async (req, res, next) => {
      






const kaga = JSON.parse(fs.readFileSync(bla + '/data/kaga.json'));
    const randkaga = kaga[Math.floor(Math.random() * kaga.length)];
    data = await fetch(randkaga).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/kaga.jpeg', data)
    res.sendFile(bla + '/tmp/kaga.jpeg')
 
})

app.get('/random/kotori', async (req, res, next) => {
      






const kotori = JSON.parse(fs.readFileSync(bla + '/data/kotori.json'));
    const randkotori = kotori[Math.floor(Math.random() * kotori.length)];
    data = await fetch(randkotori).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/kotori.jpeg', data)
    res.sendFile(bla + '/tmp/kotori.jpeg')
 
})

app.get('/random/mikasa', async (req, res, next) => {
      






const mikasa = JSON.parse(fs.readFileSync(bla + '/data/mikasa.json'));
    const randmikasa = mikasa[Math.floor(Math.random() * mikasa.length)];
    data = await fetch(randmikasa).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/mikasa.jpeg', data)
    res.sendFile(bla + '/tmp/mikasa.jpeg')
 
})

app.get('/random/akiyama', async (req, res, next) => {
      






const akiyama = JSON.parse(fs.readFileSync(bla + '/data/akiyama.json'));
    const randakiyama = akiyama[Math.floor(Math.random() * akiyama.length)];
    data = await fetch(randakiyama).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/akiyama.jpeg', data)
    res.sendFile(bla + '/tmp/akiyama.jpeg')
 
})

app.get('/random/gremory', async (req, res, next) => {
      






const gremory = JSON.parse(fs.readFileSync(bla + '/data/gremory.json'));
    const randgremory = gremory[Math.floor(Math.random() * gremory.length)];
    data = await fetch(randgremory).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/gremory.jpeg', data)
    res.sendFile(bla + '/tmp/gremory.jpeg')
 
})

app.get('/random/isuzu', async (req, res, next) => {
      






const isuzu = JSON.parse(fs.readFileSync(bla + '/data/isuzu.json'));
    const randisuzu = isuzu[Math.floor(Math.random() * isuzu.length)];
    data = await fetch(randisuzu).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/isuzu.jpeg', data)
    res.sendFile(bla + '/tmp/isuzu.jpeg')
 
})

app.get('/random/cosplay', async (req, res, next) => {
      






const cosplay = JSON.parse(fs.readFileSync(bla + '/data/cosplay.json'));
    const randcosplay = cosplay[Math.floor(Math.random() * cosplay.length)];
    data = await fetch(randcosplay).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/cosplay.jpeg', data)
    res.sendFile(bla + '/tmp/cosplay.jpeg')
 
})

app.get('/random/shina', async (req, res, next) => {
      






const shina = JSON.parse(fs.readFileSync(bla + '/data/shina.json'));
    const randshina = shina[Math.floor(Math.random() * shina.length)];
    data = await fetch(randshina).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/shina.jpeg', data)
    res.sendFile(bla + '/tmp/shina.jpeg')
 
})

app.get('/random/kagura', async (req, res, next) => {
      






const kagura = JSON.parse(fs.readFileSync(bla + '/data/kagura.json'));
    const randkagura = kagura[Math.floor(Math.random() * kagura.length)];
    data = await fetch(randkagura).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/kagura.jpeg', data)
    res.sendFile(bla + '/tmp/kagura.jpeg')
 
})

app.get('/random/shinka', async (req, res, next) => {
      






const shinka = JSON.parse(fs.readFileSync(bla + '/data/shinka.json'));
    const randshinka = shinka[Math.floor(Math.random() * shinka.length)];
    data = await fetch(randshinka).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/shinka.jpeg', data)
    res.sendFile(bla + '/tmp/shinka.jpeg')
 
})

app.get('/random/eba', async (req, res, next) => {
      






const eba = JSON.parse(fs.readFileSync(bla + '/data/eba.json'));
    const randeba = eba[Math.floor(Math.random() * eba.length)];
    data = await fetch(randeba).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/eba.jpeg', data)
    res.sendFile(bla + '/tmp/eba.jpeg')
 
})

app.get('/random/deidara', async (req, res, next) => {
      






const Deidara = JSON.parse(fs.readFileSync(bla + '/data/deidara.json'));
    const randDeidara = Deidara[Math.floor(Math.random() * Deidara.length)];
    data = await fetch(randDeidara).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/deidara.jpeg', data)
    res.sendFile(bla + '/tmp/deidara.jpeg')
 
})



app.get('/random/jeni', async (req, res, next) => {
      






	   

    const jeni = JSON.parse(fs.readFileSync(bla + '/data/jeni.json'));
    const randjeni = jeni[Math.floor(Math.random() * jeni.length)];
    data = await fetch(randjeni).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/jeni.jpeg', data)
    res.sendFile(bla + '/tmp/jeni.jpeg')
 
})


app.get('/random/meme', async (req, res, next) => {
      






const meme = JSON.parse(fs.readFileSync(bla + '/data/meme.json'));
    const randmeme = meme[Math.floor(Math.random() * meme.length)];
    data = await fetch(randmeme).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/meme.jpeg', data)
    res.sendFile(bla + '/tmp/meme.jpeg')
 
})

app.get('/wallpaper/satanic', async (req, res, next) => {
      






    const satanic = JSON.parse(fs.readFileSync(bla + '/data/satanic.json'));
    const randsatanic = satanic[Math.floor(Math.random() * satanic.length)];
    data = await fetch(randsatanic).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/satanic.jpeg', data)
    res.sendFile(bla + '/tmp/satanic.jpeg')
 
})



app.get('/random/itachi', async (req, res, next) => {
      






const Itachi = JSON.parse(fs.readFileSync(bla + '/data/itachi.json'));
    const randItachi = Itachi[Math.floor(Math.random() * Itachi.length)];
    data = await fetch(randItachi).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/ita.jpeg', data)
    res.sendFile(bla + '/tmp/ita.jpeg')
 
})

app.get('/random/madara', async (req, res, next) => {
      






const Madara = JSON.parse(fs.readFileSync(bla + '/data/madara.json'));
    const randMadara = Madara[Math.floor(Math.random() * Madara.length)];
    data = await fetch(randMadara).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/madara.jpeg', data)
    res.sendFile(bla + '/tmp/madara.jpeg')
 
})

app.get('/random/yuki', async (req, res, next) => {
      






const Yuki = JSON.parse(fs.readFileSync(bla + '/data/yuki.json'));
    const randYuki = Yuki[Math.floor(Math.random() * Yuki.length)];
    data = await fetch(randYuki).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/yuki.jpeg', data)
    res.sendFile(bla + '/tmp/yuki.jpeg')
 
})

app.get('/wallpaper/asuna', async (req, res, next) => {
      






const asuna = JSON.parse(fs.readFileSync(bla + '/data/asuna.json'));
    const randasuna = asuna[Math.floor(Math.random() * asuna.length)];
    data = await fetch(randasuna).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/asuna.jpeg', data)
    res.sendFile(bla + '/tmp/asuna.jpeg')
 
})

app.get('/random/ayuzawa', async (req, res, next) => {
      






const ayuzawa = JSON.parse(fs.readFileSync(bla + '/data/ayuzawa.json'));
    const randayuzawa = ayuzawa[Math.floor(Math.random() * ayuzawa.length)];
    data = await fetch(randayuzawa).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/ayuzawa.jpeg', data)
    res.sendFile(bla + '/tmp/ayuzawa.jpeg')
 
})

app.get('/random/chitoge', async (req, res, next) => {
      






const chitoge = JSON.parse(fs.readFileSync(bla + '/data/chitoge.json'));
    const randchitoge = chitoge[Math.floor(Math.random() * chitoge.length)];
    data = await fetch(randchitoge).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/chitoge.jpeg', data)
    res.sendFile(bla + '/tmp/chitoge.jpeg')
 
})

app.get('/random/emilia', async (req, res, next) => {
      






const emilia = JSON.parse(fs.readFileSync(bla + '/data/emilia.json'));
    const randemilia = emilia[Math.floor(Math.random() * emilia.length)];
    data = await fetch(randemilia).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/emilia.jpeg', data)
    res.sendFile(bla + '/tmp/emilia.jpeg')
 
})

app.get('/random/hestia', async (req, res, next) => {
      






const hestia = JSON.parse(fs.readFileSync(bla + '/data/hestia.json'));
    const randhestia = hestia[Math.floor(Math.random() * hestia.length)];
    data = await fetch(randhestia).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/hestia.jpeg', data)
    res.sendFile(bla + '/tmp/hestia.jpeg')
 
})

app.get('/random/inori', async (req, res, next) => {
      






const inori = JSON.parse(fs.readFileSync(bla + '/data/inori.json'));
    const randinori = inori[Math.floor(Math.random() * inori.length)];
    data = await fetch(randinori).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/inori.jpeg', data)
    res.sendFile(bla + '/tmp/inori.jpeg')
 
})

app.get('/random/ana', async (req, res, next) => {
      






const ana = JSON.parse(fs.readFileSync(bla + '/data/ana.json'));
    const randana = ana[Math.floor(Math.random() * ana.length)];
    data = await fetch(randana).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/ana.jpeg', data)
    res.sendFile(bla + '/tmp/ana.jpeg')
 
})

app.get('/random/boruto', async (req, res, next) => {
      






const Boruto = JSON.parse(fs.readFileSync(bla + '/data/boruto.json'));
    const randBoruto = Boruto[Math.floor(Math.random() * Boruto.length)];
    data = await fetch(randBoruto).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/bor.jpeg', data)
    res.sendFile(bla + '/tmp/bor.jpeg')
 
})

app.get('/random/erza', async (req, res, next) => {
      






const Erza = JSON.parse(fs.readFileSync(bla + '/data/erza.json'));
    const randErza = Erza[Math.floor(Math.random() * Erza.length)];
    data = await fetch(randErza).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/erza.jpeg', data)
    res.sendFile(bla + '/tmp/erza.jpeg')
 
})

app.get('/random/kakashi', async (req, res, next) => {
      






const Kakasih = JSON.parse(fs.readFileSync(bla + '/data/kakasih.json'));
    const randKakasih = Kakasih[Math.floor(Math.random() * Kakasih.length)];
    data = await fetch(randKakasih).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/ka.jpeg', data)
    res.sendFile(bla + '/tmp/ka.jpeg')
 
})

app.get('/random/sagiri', async (req, res, next) => {
      






const Sagiri = JSON.parse(fs.readFileSync(bla + '/data/sagiri.json'));
    const randSagiri = Sagiri[Math.floor(Math.random() * Sagiri.length)];
    data = await fetch(randSagiri).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/sagiri.jpeg', data)
    res.sendFile(bla + '/tmp/sagiri.jpeg')
 
})

app.get('/random/minato', async (req, res, next) => {
      






const Minato = JSON.parse(fs.readFileSync(bla + '/data/minato.json'));
    const randMinato = Minato[Math.floor(Math.random() * Minato.length)];
    data = await fetch(randMinato).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/minato.jpeg', data)
    res.sendFile(bla + '/tmp/minato.jpeg')
 
})

app.get('/random/naruto', async (req, res, next) => {
      






const Naruto = JSON.parse(fs.readFileSync(bla + '/data/naruto.json'));
    const randNaruto = Naruto[Math.floor(Math.random() * Naruto.length)];
    data = await fetch(randNaruto).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/naruto.jpeg', data)
    res.sendFile(bla + '/tmp/naruto.jpeg')
 
})

app.get('/random/nezuko', async (req, res, next) => {
      






const Nezuko = JSON.parse(fs.readFileSync(bla + '/data/nezuko.json'));
    const randNezuko = Nezuko[Math.floor(Math.random() * Nezuko.length)];
    data = await fetch(randNezuko).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/nezu.jpeg', data)
    res.sendFile(bla + '/tmp/nezu.jpeg')
 
})

app.get('/random/onepiece', async (req, res, next) => {
      






const Pic = JSON.parse(fs.readFileSync(bla + '/data/onepiece.json'));
    const randPic = Pic[Math.floor(Math.random() * Pic.length)];
    data = await fetch(randPic).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/pic.jpeg', data)
    res.sendFile(bla + '/tmp/pic.jpeg')
 
})

app.get('/random/rize', async (req, res, next) => {
      






const Rize = JSON.parse(fs.readFileSync(bla + '/data/rize.json'));
    const randRize = Rize[Math.floor(Math.random() * Rize.length)];
    data = await fetch(randRize).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/rize.jpeg', data)
    res.sendFile(bla + '/tmp/rize.jpeg')
 
})

app.get('/random/sakura', async (req, res, next) => {
      






const Sakura = JSON.parse(fs.readFileSync(bla + '/data/sakura.json'));
    const randSakura = Sakura[Math.floor(Math.random() * Sakura.length)];
    data = await fetch(randSakura).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/sakura.jpeg', data)
    res.sendFile(bla + '/tmp/sakura.jpeg')
 
})

app.get('/random/sasuke', async (req, res, next) => {
      






const Sasuke = JSON.parse(fs.readFileSync(bla + '/data/sasuke.json'));
    const randSasuke = Sasuke[Math.floor(Math.random() * Sasuke.length)];
    data = await fetch(randSasuke).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/sasuke.jpeg', data)
    res.sendFile(bla + '/tmp/sasuke.jpeg')
 
})

app.get('/random/tsunade', async (req, res, next) => {
      






const Su = JSON.parse(fs.readFileSync(bla + '/data/tsunade.json'));
    const randSu = Su[Math.floor(Math.random() * Su.length)];
    data = await fetch(randSu).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/su.jpeg', data)
    res.sendFile(bla + '/tmp/su.jpeg')
 
})

app.get('/random/montor', async (req, res, next) => {
      






const Mon = JSON.parse(fs.readFileSync(bla + '/data/montor.json'));
    const randMon = Mon[Math.floor(Math.random() * Mon.length)];
    data = await fetch(randMon).then(v => v.buffer());
    await fs.writeFileSync(bla + '/tmp/montor.jpeg', data)
    res.sendFile(bla + '/tmp/montor.jpeg');
 
})

app.get('/random/mobil', async (req, res, next) => {
      






const Mob = JSON.parse(fs.readFileSync(bla + '/data/mobil.json'));
    const randMob = Mob[Math.floor(Math.random() * Mob.length)];
    data = await fetch(randMob).then(v => v.buffer());
    await fs.writeFileSync(bla + '/tmp/mobil.jpeg', data)
    res.sendFile(bla + '/tmp/mobil.jpeg');
 
})


app.get('/random/anime', async (req, res, next) => {
      






const Wai23 = JSON.parse(fs.readFileSync(bla + '/data/wallhp2.json'));
    const randWai23 = Wai23[Math.floor(Math.random() * Wai23.length)];
    data = await fetch(randWai23).then(v => v.buffer());
    await fs.writeFileSync(bla + '/tmp/wallhp2.jpeg', data)
    res.sendFile(bla + '/tmp/wallhp2.jpeg');
 
})


app.get('/random/wallhp', async (req, res, next) => {
      






	   

    const Wai22 = JSON.parse(fs.readFileSync(bla + '/data/wallhp.json'));
    const randWai22 = Wai22[Math.floor(Math.random() * Wai22.length)];
    data = await fetch(randWai22).then(v => v.buffer());
    await fs.writeFileSync(bla + '/tmp/wallhp.jpeg', data)
    res.sendFile(bla + '/tmp/wallhp.jpeg');
 
})

app.get('/random/waifu2', async (req, res, next) => {
      






    const Wai2 = JSON.parse(fs.readFileSync(bla + '/data/waifu2.json'));
    const randWai2 = Wai2[Math.floor(Math.random() * Wai2.length)];
    data = await fetch(randWai2).then(v => v.buffer());
    await fs.writeFileSync(bla + '/tmp/wibu2.jpeg', data)
    res.sendFile(bla + '/tmp/wibu2.jpeg');
})

app.get('/random/waifu', async (req, res, next) => {
    const Wai = JSON.parse(fs.readFileSync(bla + '/data/waifu.json'));
    const randWai = Wai[Math.floor(Math.random() * Wai.length)];
    data = await fetch(randWai).then(v => v.buffer());
    await fs.writeFileSync(bla + '/tmp/wibu.jpeg', data)
    res.sendFile(bla + '/tmp/wibu.jpeg');
 
})


app.get('/random/hekel', async (req, res, next) => {
      






	Hekel = JSON.parse(fs.readFileSync(bla + '/data/hekel.json'));
    const randHekel = Hekel[Math.floor(Math.random() * Hekel.length)]
    data = await fetch(randHekel).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/hek.jpeg', data)
    res.sendFile(bla + '/tmp/hek.jpeg')
 
})

app.get('/random/kucing', async (req, res, next) => {
      






Kucing = JSON.parse(fs.readFileSync(bla + '/data/kucing.json'));
    const randKucing = Kucing[Math.floor(Math.random() * Kucing.length)]
    data = await fetch(randKucing).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/kucing.jpeg', data)
    res.sendFile(bla + '/tmp/kucing.jpeg')
 
})

app.get('/wallpaper/pubg', async (req, res, next) => {
      






Pubg = JSON.parse(fs.readFileSync(bla + '/data/pubg.json'));
    const randPubg = Pubg[Math.floor(Math.random() * Pubg.length)]
    data = await fetch(randPubg).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/pubg.jpeg', data)
    res.sendFile(bla + '/tmp/pubg.jpeg')
 
})

app.get('/wallpaper/ppcouple', async (req, res, next) => {
      






Pp = JSON.parse(fs.readFileSync(bla + '/data/profil.json'));
    const randPp = Pp[Math.floor(Math.random() * Pp.length)]
    data = await fetch(randPp).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/pp.jpeg', data)
    res.sendFile(bla + '/tmp/pp.jpeg')
 
})

app.get('/wallpaper/anjing', async (req, res, next) => {
      






Anjing = JSON.parse(fs.readFileSync(bla + '/data/anjing.json'));
    const randAnjing = Anjing[Math.floor(Math.random() * Anjing.length)]
    data = await fetch(randAnjing).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/ajg.jpeg', data)
    res.sendFile(bla + '/tmp/ajg.jpeg')
 
})

app.get('/random/doraemon', async (req, res, next) => {
      






Dora = JSON.parse(fs.readFileSync(bla + '/data/doraemon.json'));
    const randDora = Dora[Math.floor(Math.random() * Dora.length)]
    data = await fetch(randDora).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/dora.jpeg', data)
    res.sendFile(bla + '/tmp/dora.jpeg')
 
})


app.get('/random/elaina', async (req, res, next) => {
      






const Elaina = JSON.parse(fs.readFileSync(bla + '/data/elaina.json'))
    const randElaina = Elaina[Math.floor(Math.random() * Elaina.length)]
    //tansole.log(randLoli)
    data = await fetch(randElaina).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/elaina.jpeg', data)
    res.sendFile(bla + '/tmp/elaina.jpeg')
 
})


app.get('/random/loli', async (req, res, next) => {
      






const Loli = JSON.parse(fs.readFileSync(bla + '/data/loli.json'))
    const randLoli = Loli[Math.floor(Math.random() * Loli.length)]
    //tansole.log(randLoli)
    data = await fetch(randLoli).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/loli.jpeg', data)
    res.sendFile(bla + '/tmp/loli.jpeg')
 
})


app.get('/random/yuri', async (req, res, next) => {
      






const Yuri = JSON.parse(fs.readFileSync(bla + '/data/yuri.json'))
    const randYuri = Yuri[Math.floor(Math.random() * Yuri.length)]
    //tansole.log(randTech)
    data = await fetch(randYuri).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/Yuri.jpeg', data)
    res.sendFile(bla + '/tmp/Yuri.jpeg')
 
})


app.get('/random/cecan', async (req, res, next) => {
      






const cecan = JSON.parse(fs.readFileSync(bla + '/data/cecan.json'));
    const randCecan = cecan[Math.floor(Math.random() * cecan.length)];
    data = await fetch(randCecan).then(v => v.buffer());
    await fs.writeFileSync(bla + '/tmp/cecan.jpeg', data)
    res.sendFile(bla + '/tmp/cecan.jpeg');
 
})


app.get('/wallpaper/aesthetic', async (req, res, next) => {
      






const Aesthetic = JSON.parse(fs.readFileSync(bla + '/data/aesthetic.json'));
    const randAesthetic = Aesthetic[Math.floor(Math.random() * Aesthetic.length)];
    data = await fetch(randAesthetic).then(v => v.buffer());
    await fs.writeFileSync(bla + '/tmp/aesthetic.jpeg', data)
    res.sendFile(bla + '/tmp/aesthetic.jpeg');
 
})


app.get('/random/sagiri', async (req, res, next) => {
      






const Sagiri = JSON.parse(fs.readFileSync(bla + '/data/sagiri.json'));
    const randSagiri = Sagiri[Math.floor(Math.random() * Sagiri.length)];
    data = await fetch(randSagiri).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/sagiri.jpeg', data)
    res.sendFile(bla + '/tmp/sagiri.jpeg')
 
})

app.get('/random/shota', async (req, res, next) => {
      






const Shota = JSON.parse(fs.readFileSync(bla + '/data/shota.json'));
    const randShota = Shota[Math.floor(Math.random() * Shota.length)];
    data = await fetch(randShota).then(v => v.buffer());
    await fs.writeFileSync(bla + '/tmp/shota.jpeg', data)
    res.sendFile(bla + '/tmp/shota.jpeg');
 
})

app.get('/random/nsfwloli', async (req, res, next) => {
      






    const lol = JSON.parse(fs.readFileSync(bla + '/data/nsfwloli.json'));
    const randlol = lol[Math.floor(Math.random() * lol.length)];
    data = await fetch(randlol).then(v => v.buffer());
    await fs.writeFileSync(bla + '/tmp/lol.jpeg', data)
    res.sendFile(bla + '/tmp/lol.jpeg');
 
})

app.get('/random/hinata', async (req, res, next) => {
      






    const Hinata = JSON.parse(fs.readFileSync(bla + '/data/hinata.json'));
    const randHin = Hinata[Math.floor(Math.random() * Hinata.length)];
    data = await fetch(randHin).then(v => v.buffer());
    await fs.writeFileSync(bla + '/tmp/Hinata.jpeg', data)
    res.sendFile(bla + '/tmp/Hinata.jpeg');
 
})

app.get('/api/soundcloud', async(req, res, next) => {
 






 url = req.query.url
if (!url) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: url"})
soundl(url).then((resultado) => {
 res.json({
 status: true,
 código: 200,
 criador: `${criador}`,
 resultado: resultado
 })}).catch(e => {
res.json({
 resultado: `Erro no Servidor Interno`
 })})})

app.get('/api/manga', async(req, res, next) => {
 






q = req.query.q
if (!q) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: q"})
manga(q).then((resultado) => {
 res.json({
 status: true,
 código: 200,
 criador: `${criador}`,
 resultado: resultado
 })}).catch(e => {
res.json({
 resultado: `Erro no Servidor Interno`
 })})})

app.get('/api/hentaistube', async(req, res, next) => {
 






q = req.query.q
if (!q) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: q"})
hentaistube(q).then((resultado) => {
 res.json({
 status: true,
 código: 200,
 criador: `${criador}`,
 resultado: resultado
 })}).catch(e => {
res.json({
 resultado: `Erro no Servidor Interno`
 })})})
 
app.get('/api/animes', async(req, res, next) => {
 






q = req.query.q
if (!q) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: q"})
anime(q).then((resultado) => {
 res.json({
 status: true,
 código: 200,
 criador: `${criador}`,
 resultado: resultado
 })}).catch(e => {
res.json({
 resultado: `Erro no Servidor Interno`
 })})})


app.get('/api/ttp',  async (req, res) => {
texto = req.query.texto
if(!texto)return res.json({
status:false,
resultado:'Cade o parametro texto??'
})







cor = ["f702ff","ff0202","00ff2e","efff00","00ecff","3100ff","ffb400","ff00b0","00ff95","efff00"] //CORES COLOQUE QUALQUER UMA MAS EM CODE
fonte = ["Days%20One","Domine","Exo","Fredoka%20One","Gentium%20Basic","Gloria%20Hallelujah","Great%20Vibes","Orbitron","PT%20Serif","Pacifico"]//FONTS NÃO MEXA
cores = cor[Math.floor(Math.random() * (cor.length))]	 				 
fontes = fonte[Math.floor(Math.random() * (fonte.length))]	 		
sitee = `https://huratera.sirv.com/PicsArt_08-01-10.00.42.png?profile=Example-Text&text.0.text=${texto}&text.0.outline.color=000000&text.0.outline.blur=0&text.0.outline.opacity=55&text.0.color=${cores}&text.0.font.family=${fontes}&text.0.background.color=ff0000`
res.type('jpg')
res.send(await getBuffer(sitee))
})

app.get('/api/fbdown', async(req,res) => {
url = req.query.url
if(!url)return res.json({
status:false,
resultado:'Cade o parametro url??'
})







down.fbdown(url)
.then(e => {
res.json({
status:true,
criador: `${criador}`,
resultado: e})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})
 
app.get('/api/clima', async(req,res) => {
query = req.query.query
if(!query)return res.json({status:false,resultado:'Cade o parametro query??'})







const { climaDl } = require('./modulos-api/clima.js');
climaDl(query)
.then(e => {
res.json({
status:true,
criador: `${criador}`,
resultado: e
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/photooxy', async(req,res) => {
url = req.query.url
text = req.query.text
if(!url)return res.json({
status:false,
resultado:'Cade o parametro url??'
})
if(!text)return res.json({
status:false,
resultado:'Cade o parametro text??'
})







photooxy(url, text)
.then(e => {
res.json({
status:true,
criador: `${criador}`,
resultado: e})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/wallpaperanime', async(req,res) => {







q = 'Wallpaper anime'
gis(q, async (error, results) => {
if (error) {
console.log(error)
res.json({
status:false,
resultado:'Não encontrei imagem'
})
} else {
bala = await getBuffer(results[1].url)
res.type('jpg')
res.send(bala)
}
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})


app.get('/api/avatar', async(req,res,next) => {
fetch(encodeURI(`https://nekos.life/api/v2/img/avatar`))
.then(response => response.json())
.then(async (data) => {
resultado =  data
bala = await getBuffer(resultado.url)
res.type('jpg')
res.send(bala)
})
.catch(e => {
res.json({resultado: `${msgerro}`})
})
})


app.get('/api/legenda',async (req,res,next) => {
url = req.query.url
texto1 = req.query.texto1
texto2 = req.query.texto2
if(!url)return res.json({
status:false,
motivo:'nao_tem_url'
})
if(!texto1)return res.json({
status:false,
motivo:'nao_tem_texto_1'
})
if(!texto2)return res.json({
status:false,
motivo:'nao_tem_texto_2'
})
bala = await getBuffer(`https://api.memegen.link/images/custom/${texto1}/${texto2}.png?background=${url}`)
res.type('jpg')
res.send(bala)
})

app.get('/api/plaq',async (req,res,next) => {
var texto = req.query.texto
if(!texto)return res.json({status:false,motivo: 'Cade o texto'})







try {
bala = await getBuffer(`https://umethroo.sirv.com/Torcedora-da-sele%C3%A7%C3%A3o-brasileira-nua-mostrando-a-bunda-236x300.jpg?text.0.text=${texto}&text.0.position.x=-64%25&text.0.position.y=-39%25&text.0.size=25&text.0.color=1b1a1a&text.0.font.family=Architects%20Daughter`)
res.type('jpg')
res.send(bala)
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/api/plaq1',async (req,res,next) => {
var texto = req.query.texto
if(!texto)return res.json({status:false,motivo: 'Cade o texto'})







try {
bala = await getBuffer(`https://raptibef.sirv.com/images%20(1).jpeg?profile=Zanga%202.0&text.0.text=${texto}`)
res.type('jpg')
res.send(bala)
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/api/plaq2',async (req,res,next) => {
var texto = req.query.texto
if(!texto)return res.json({status:false,motivo: 'Cade o texto'})







try {
bala = await getBuffer(`https://raptibef.sirv.com/images.jpeg?profile=Zanga%203.0&text.0.text=${texto}&text.0.outline.blur=63`)
res.type('jpg')
res.send(bala)
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/api/plaq3',async (req,res,next) => {
var texto = req.query.texto
if(!texto)return res.json({status:false,motivo: 'Cade o texto'})







try {
bala = await getBuffer(`https://umethroo.sirv.com/peito1.jpg?text.0.text=${texto}&text.0.position.x=-4%25&text.0.position.y=-6%25&text.0.size=14&text.0.color=000000&text.0.font.family=Shadows%20Into%20Light&text.0.font.weight=700`)
res.type('jpg')
res.send(bala)
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})
 
app.get('/api/plaq4',async (req,res,next) => {
var texto = req.query.texto
if(!texto)return res.json({status:false,motivo: 'Cade o texto'})







try {
bala = await getBuffer(`https://clutamac.sirv.com/1011b781-bab1-49e3-89db-ee2c064868fa%20(1).jpg?text.0.text=${texto}&text.0.position.gravity=northwest&text.0.position.x=22%25&text.0.position.y=60%25&text.0.size=12&text.0.color=000000&text.0.opacity=47&text.0.font.family=Roboto%20Mono&text.0.font.style=italic`)
res.type('jpg')
res.send(bala)
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/api/plaq5',async (req,res,next) => {
var texto = req.query.texto
if(!texto)return res.json({status:false,motivo: 'Cade o texto'})







try {
bala = await getBuffer(`https://umethroo.sirv.com/Torcedora-da-sele%C3%A7%C3%A3o-brasileira-nua-mostrando-a-bunda-236x300.jpg?text.0.text=${texto}&text.0.position.x=-64%25&text.0.position.y=-39%25&text.0.size=25&text.0.color=1b1a1a&text.0.font.family=Architects%20Daughter`)
res.type('jpg')
res.send(bala)
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/api/plaq6',async (req,res,next) => {
var texto = req.query.texto
if(!texto)return res.json({status:false,motivo: 'Cade o texto'})







try {
bala = await getBuffer(`https://blackzin.sirv.com/Plaq18/20220212_213215.jpg?text.0.text=${texto}&text.0.position.gravity=northwest&text.0.position.x=43%25&text.0.position.y=18%25&text.0.size=15&text.0.color=000000&text.0.opacity=57&text.0.font.family=Vollkorn&text.0.font.weight=800&text.0.font.style=italic&text.0.background.color=000000&text.0.outline.blur=32&text.0.outline.opacity=46&text.1.text=Dark Domina bb%3F&text.1.position.gravity=center&text.1.position.x=10%25&text.1.position.y=30%25&text.1.size=20&text.1.color=000000&text.1.opacity=59&text.1.font.family=Playball&text.1.font.weight=700&text.1.outline.opacity=0" width="718" height="1009" alt="" />`)
res.type('jpg')
res.send(bala)
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/api/plaq7',async (req,res,next) => {
var texto = req.query.texto
if(!texto)return res.json({status:false,motivo: 'Cade o texto'})







try {
bala = await getBuffer(`https://ubbornag.sirv.com/Screenshot_20210513-151821.png?text.0.text=${texto}&text.0.position.x=-40%25&text.0.position.y=-65%25&text.0.size=30&text.0.color=000000&text.0.opacity=53&text.0.font.family=Shadows%20Into%20Light20Two&text.0.outline.blur=15`)
res.type('jpg')
res.send(bala)
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/api/plaq8',async (req,res,next) => {
var texto = req.query.texto
if(!texto)return res.json({status:false,motivo: 'Cade o texto'})







try {
bala = await getBuffer(`https://lculitas.sirv.com/ETw3FRnXgAI3Up_.jpg?text.0.text=${texto}&text.0.position.gravity=center&text.0.align=left&text.0.size=46&text.0.color=221b1b&text.0.opacity=47&text.0.font.family=Architects%20Daughter&text.0.background.color=783852&text.0.background.opacity=5&text.0.outline.blur=58`)
res.type('jpg')
res.send(bala)
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/api/github', async(req,res,next) => {
pessoa = req.query.usuario
if(!pessoa)return res.json({status:false,motivo:'cade_o_usuario'})







fetch(encodeURI(`https://api.github.com/users/`+pessoa))
.then(response => response.json())
.then(date => {
gitData =  date;
res.json({
criador:"Vitinho ツ",
status:true,
resultado:{
username: gitData.login,
id: gitData.id,
Node_ID: gitData.node_id,
url: gitData.html_url,
local: (gitData.location == null) ? 'não_tem' : gitData.location,
bio: (gitData.bio == null) ? 'não_tem' : gitData.bio,
twitter:  (gitData.twitter_username == null) ? 'não_tem' : gitData.twitter_username,
seguidores: gitData.followers,
seguindo: gitData.following,
criado: gitData.created_at,
atualizado: gitData.updated_at,
procura_trabalho: (gitData.hireable == null) ? 'Não' : gitData.hireable,
Site: (gitData.blog == "") ? 'Não' : gitData.blog,
repositorios: gitData.public_repos,
admin_de_Site: (gitData.site_admin == false) ? 'Não' : gitData.site_admin,
tipo: gitData.type,
empresa: (gitData.company == null) ? 'Não' : gitData.company,
email: (gitData.email == null) ? 'Não' : gitData.email
} 
})
}).catch(e => {
res.json({resultado: `${msgerro}`}) 
})
})

app.get('/api/wikipedia', async(req,res) => {
texto = req.query.texto
if(!texto)return res.json({
status:false,
resultado:'Cade o parametro texto??'
})







wiki.search(`${texto}`, 'pt')
.then(async (wikip) => {
const wikis = await axiosapp.get(`https://pt.wikipedia.org/w/api.php?format=json&action=query&prop=extracts&exintro&explaintext&redirects=1&pageids=${wikip[0].pageid}`)
const getData = Object.keys(wikis.data.query.pages)







res.json({
status:true,
criador: `${criador}`,
resultado:wikis.data.query.pages[getData].extract
    })
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})


app.get('/youtube/search', async(req,res) => {
query = req.query.query
if(!query)return res.json({status:false,resultado:'Cade o parametro query??'})







ytSearch(query)
.then(e => {
res.json({
status:true,
criador:  `${criador}`,
resultado:e
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

app.get('/api/playmix', async(req,res) => {
q = req.query.q
if(!q)return res.json({
status:false,
resultado:'Cade o parametro q??'
})







search(q) 
.then(e => {
res.json({
status:true,
criador:  `${criador}`,
resultado:e
})
}).catch(e => {
res.json({resultado: `${msgerro}`})
})
})

   
app.get('/youtube/play', async (req, res, next) =>  {
query = req.query.query
if(!query)return res.json({status:false, resultado:'Cade o parametro query??'  }) 







try {
zan = await yts(query)
res.json({
status: true,
creator: `${criador}`,
Title: zan.all[0].title,
Thumb: zan.all[0].image,
Description : zan.all[0].description,
Duration: zan.all[0].timestamp,
Viewer: zan.all[0].views, 
Author : zan.all[0].author.name,
Channel : zan.all[0].author.name,
Link: zan.all[0].url,
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})


/*app.get('/youtube/mp3', async (req, res, next) => {







url = req.query.url
if(!url)return res.json({status:false, resultado:'Cade o parametro url??'  }) 
try {
const down = await youtubedl(url);
const audio = await down.audio['128kbps'].download();
data = await fetch(audio).then(v => v.buffer())   
await fs.writeFileSync(bla+'/tmp/asupan.mp4', data)
res.sendFile(bla+'/tmp/asupan.mp4')
} catch (err) {
res.json({resultado: `${err}`})
};
});


app.get('/youtube/mp4', async (req, res, next) => {







url = req.query.url
if(!url)return res.json({status:false, resultado:'Cade o parametro url??'  }) 
try {
const down = await youtubedl(url);
const video = await down.video['360p'].download();
data = await fetch(video).then(v => v.buffer())   
await fs.writeFileSync(bla+'/tmp/asupan.mp4', data)
res.sendFile(bla+'/tmp/asupan.mp4')
} catch (err) {
res.json({resultado: `${msgerro}`})
};
});*/

app.get('/youtube/playlist', async(req, res, next) => {







url = req.query.url
 if (!url) return res.json({ status : false, criador : `${criador}`, resultado : "Coloque o parametro: url"})
getVideosPlaylist(url).then(resJson => {
res.json({
status: true, 
criador: `${criador}`,
resultado: resJson
})}).catch(e => {
res.json({
resultado: `${msgerro}`
})})})

app.get('/api/mememp3', async (req, res, next) => {
var query = req.query.query;
if(!query)return res.json({status:false,resultado:'- Cadê o parâmetro query?'})







try {
const { getLink } = require('./modulos-api/mememp3.js')
await getLink(query).then(e => { 
res.json({
status: true, 
criador: `${criador}`,
resultado: e,
})  
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
}) 


app.get('/api/icms', async(req, res, next) => {







try {
var valor = req.query.valor;
if(!valor)return res.json({status:false,resultado:'- Cadê o parâmetro valor?'})
var ddd = req.query.ddd;
if(!ddd)return res.json({status:false,resultado:'- Cadê o parâmetro ddd?'})
const icms = require('./modulos-api/icms.js')
await icms(valor, ddd).then((result) => {
res.json({
status: true,
criador: `${criador}`,
creditos_scrapper: `Crap-Ethern </Dev>`,
resultado: {
Icms: `${result.icms}` + '%',
Valor: `${result.total}` + '.00',
ValorTotal: `${result.icmsTotal}` + '.00',
ValorDolar: `${result.dolar}`
}
})
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/moedas/dolar', async(req, res, next) => {







try {
data = await fetchJson(`https://cdn.jsdelivr.net/gh/fawazahmed0/currency-api@1/latest/currencies/usd/brl.json`)
res.json({
status: true,
criador: `${criador}`,
date: data.date,
brl: data.brl
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/moedas/euro', async(req, res, next) => {







try {
data = await fetchJson(`https://cdn.jsdelivr.net/gh/fawazahmed0/currency-api@1/latest/currencies/eur/brl.json`)
res.json({
status: true,
criador: `${criador}`,
date: data.date,
brl: data.brl
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/moedas/bitcoin', async(req, res, next) => {







try {
data = await fetchJson(`https://cdn.jsdelivr.net/gh/fawazahmed0/currency-api@1/latest/currencies/btc/brl.json`)
res.json({
status: true,
criador: `${criador}`,
date: data.date,
brl: data.brl
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/moedas/eth', async(req, res, next) => {







try {
data = await fetchJson(`https://cdn.jsdelivr.net/gh/fawazahmed0/currency-api@1/latest/currencies/eth/brl.json`)
res.json({
status: true,
criador: `${criador}`,
date: data.date,
brl: data.brl
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
}) 

app.get('/moedas/euro/brl', async(req, res, next) => {







try {
await axios.get(`https://economia.awesomeapi.com.br/last/EUR-BRL`).then((response) => {
res.json({
status: true,
criador: `${criador}`,
resultado: response.data.EURBRL
})
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/moedas/bitcoin/brl', async(req, res, next) => {







try {
await axios.get(`https://economia.awesomeapi.com.br/last/BTC-BRL`).then((response) => {
res.json({
status: true,
criador: `${criador}`,
resultado: response.data.BTCBRL
})
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/moedas/libra/brl', async(req, res, next) => {







try {
await axios.get(`https://economia.awesomeapi.com.br/last/GBP-BRL`).then((response) => {
res.json({
status: true,
criador: `${criador}`,
resultado: response.data.GBPBRL
})
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/moedas/ethereum/brl', async(req, res, next) => {







try {
await axios.get(`https://economia.awesomeapi.com.br/last/ETH-BRL`).then((response) => {
res.json({
status: true,
criador: `${criador}`,
resultado: response.data.ETHBRL
})
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/moedas/dolar/brl', async(req, res, next) => {







try {
await axios.get(`https://economia.awesomeapi.com.br/last/USD-BRL`).then((response) => {
res.json({
status: true, 
criador: `${criador}`, 
resultado: response.data.USDBRL
})
})  
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})

app.get('/tempmail/criar-email', async(req, res, next) => {







try {
var resS = await axios.get('https://www.1secmail.com/api/v1/?action=genRandomMailbox')
var data = await resS.data;
res.json({
status: true,
criador: `${criador}`,
resultado: data
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})
 
app.get('/tempmail/ler-inbox', async(req, res, next) => {

var login = req.query.login;
var domain = req.query.domain;
if(!login)return res.json({status:false,resultado: 'Cadê o parâmetro login?'})
if(!domain)return res.json({status:false,resultado:'- Cadê o parâmetro domain?'})






try {
var ress = await axios.get(`https://www.1secmail.com/api/v1/?action=getMessages&login=${login}&domain=${domain}`);
var data = ress.data;
res.json({
status: true,
criador: `${criador}`, 
resultado: data
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
}) 

app.get('/tempmail/ler-email', async(req, res, next) => {

var login = req.query.login;
var domain = req.query.domain;
var id = req.query.id;
if(!login)return res.json({status:false,resultado: 'Cadê o parâmetro login?'})
if(!domain)return res.json({status:false,resultado:'- Cadê o parâmetro domain?'})
if(!id)return res.json({status:false,resultado:'- Cadê o parâmetro id?'})






try {
var url = `https://www.1secmail.com/api/v1/?action=readMessage&login=${login}&domain=${domain}&id=${id}`
console.log(login , domain, id)
var ress = await axios.get(url)
var data = await ress.data
res.json({
status: true,
criador: `${criador}`,
resultado: data
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
})
//***************CARD CANVAS*************************\\

    router.get('/card/rank', async (req, res) => {
     apikey = req.query.apikey;
     username = req.query.nome,
     perfil = req.query.perfil,
     fundo = req.query.fundo,           
     xp = req.query.xp,           
     fullxp = req.query.fullxp,           
     level = req.query.level,
     rank = req.query.rank,
     discrim = req.query.contagem
     cor = req.query.cor
     if (apikey === undefined || username === undefined || xp === undefined || perfil === undefined || discrim === undefined || fundo === undefined || fullxp === undefined || level === undefined || rank === undefined || cor === undefined) return res.status(404).send({
    status: 404,
    message: `insira o parâmetro apikey & nome & fundo & xp & fullxp & level & rank & contagem & cor`
    });
    const check = await cekKey(apikey);
    if (!check) return res.status(403).send({
    status: 403,
    mensagem: `apikey: ${apikey} não encontrada, por favor registre-se primeiro!`
    });
    let limit = await isLimit(apikey);
    if (limit) return res.status(403).send({status: 403, message: 'seu limit acabou volte amanhã ou compre o premium...'});
    limitAdd(apikey);        
     ran = getRandom('.jpg')
    rano = getRandom('.jpg')
    buff = await getBuffer(perfil)
    fs.writeFileSync(ran, buff)
    anu = await TelegraPh(ran)
     let img = await blarank.rank({ 
            username, 
            discrim, 
            level: level, 
            rank: rank, 
            neededXP: xp, 
            currentXP: fullxp, 
            avatarURL: util.format(anu), 
            color: cor, 
            background: `${fundo}`
        });
  await fs.writeFileSync(bla +'/tmp/rank.png', img)
  res.sendFile(bla+'/tmp/rank.png')
   });
   
   
   router.get('/card/menu', async (req, res) => {
    apikey = req.query.apikey;
    usuario = req.query.nome,
    numero = req.query.numero,
    perfil = req.query.perfil,
    fundo = req.query.fundo,
    titulo = req.query.titulo,
    cor1 = req.query.cor1,
    cor2 = req.query.cor2
     if (apikey === undefined || usuario === undefined || numero === undefined || titulo === undefined || fundo === undefined || perfil === undefined || cor1 === undefined || cor2 === undefined) return res.status(404).send({
    status: 404,
    message: `insira o parâmetro apikey & nome & numero & titulo & membros & fundo & perfil & cor1 & cor2`
    });
    const check = await cekKey(apikey);
    if (!check) return res.status(403).send({
    status: 403,
    mensagem: `apikey: ${apikey} não encontrada, por favor registre-se primeiro!`
    });
    let limit = await isLimit(apikey);
    if (limit) return res.status(403).send({status: 403, message: 'seu limit acabou volte amanhã ou compre o premium...'});
    limitAdd(apikey);
    let img = await blarank.welcome({ 
            username: usuario, 
            discrim: numero,
            avatarURL: perfil,
            fundo: fundo,
            titulo: titulo,
            cor1: `#${cor1}`,
            cor2: `#${cor2}`
        });
   await fs.writeFileSync(bla +'/tmp/menu.png', img)
  res.sendFile(bla+'/tmp/menu.png')
   });
   
   
   router.get('/canvas/welcome', async (req, res, next) => {
        var apikeyInput = req.query.apikey,
            nome = req.query.nome,
            numero = req.query.numero,
            perfil = req.query.perfil,
            fundo = req.query.fundo,
            titulo = req.query.titulo,
            cor1 = req.query.cor1,
            cor2 = req.query.cor2
	if(!apikeyInput) return res.json(loghandler.notparam)
	if(apikeyInput !== `${key}`) return res.sendFile(invalidKey)
    if (!nome) return res.json({ status : false, criador : `${creator}`, message : "coloque o parametrô nome"})
    if (!numero) return res.json({ status : false, criador : `${creator}`, message : "coloque o parametrô numero"})
    if (!fundo) return res.json({ status : false, criador : `${creator}`, message : "coloque o parametrô fundo"})                
    if (!perfil) return res.json({ status : false, criador : `${creator}`, message : "coloque o parametrô perfil"})    
    if (!titulo) return res.json({ status : false, criador : `${creator}`, message : "coloque o parametrô titulo"})  
    if (!cor1) return res.json({ status : false, criador : `${creator}`, message : "coloque o parametrô cor1"})  
    if (!cor2) return res.json({ status : false, criador : `${creator}`, message : "coloque o parametrô cor2"})      
     let img = await blarank.welcome({ 
            username: nome, 
            discrim: numero,
            avatarURL: perfil,
            fundo: fundo,
            titulo: titulo,
            cor1: `#${cor1}`,
            cor2: `#${cor2}`
        });
        await fs.writeFileSync(__path +'/tmp/welcome.png', img)
  res.sendFile(__path+'/tmp/welcome.png')
         .catch(e => {
         	res.sendFile(error)
})
})

    router.get('/card/welcome', async (req, res) => {
    const apikey = req.query.apikey;
    const nome = req.query.nome;    
    const nomegp = req.query.nomegp;    
    const fotogp = req.query.fotogp;    
    const perfil = req.query.perfil;            
    const membros = req.query.membros;
    const fundo = req.query.fundo;        
     if (apikey === undefined || nome === undefined || nomegp === undefined || fotogp === undefined || membros === undefined || fundo === undefined || perfil === undefined) return res.status(404).send({
    status: 404,
    message: `insira o parâmetro apikey & nome & nomegp & fotogp & membros & fundo & perfil`
    });
    const check = await cekKey(apikey);
    if (!check) return res.status(403).send({
    status: 403,
    mensagem: `apikey: ${apikey} não encontrada, por favor registre-se primeiro!`
    });
    let limit = await isLimit(apikey);
    if (limit) return res.status(403).send({status: 403, message: 'seu limit acabou volte amanhã ou compre o premium...'});
    limitAdd(apikey);
var image = await new knights.Welcome()
    .setUsername(`${nome}`)
    .setGuildName(`${nomegp}`)
    .setGuildIcon(`${fotogp}`)
    .setMemberCount(`${membros}`)
    .setAvatar(`${perfil}`)
    .setBackground(`${fundo}`)
    .toAttachment();
  data = image.toBuffer();
  await fs.writeFileSync(bla +'/tmp/bemvindo.png', data)
  res.sendFile(bla +'/tmp/bemvindo.png')
   });
   
   router.get('/card/welcomev2', async (req, res) => {
    const apikey = req.query.apikey;
    const nome = req.query.nome;    
    const nomegp = req.query.nomegp;    
    const perfil = req.query.perfil;            
    const membros = req.query.membros;
    const titulo = req.query.titulo;        
    const numero = req.query.numero;
    const cor = req.query.cor;
    const lcor = req.query.lcor;
    const tcor = req.query.tcor;
    const fundo = req.query.fundo;
     if (apikey === undefined || nome === undefined || nomegp === undefined || titulo === undefined || membros === undefined || fundo === undefined || perfil === undefined || numero === undefined || cor === undefined || lcor === undefined || tcor === undefined) return res.status(404).send({
    status: 404,
    message: `insira o parâmetro apikey & nome & nomegp & titulo & membros & fundo & perfil & numero & cor & lcor`
    });
    const check = await cekKey(apikey);
    if (!check) return res.status(403).send({
    status: 403,
    mensagem: `apikey: ${apikey} não encontrada, por favor registre-se primeiro!`
    });
    let limit = await isLimit(apikey);
    if (limit) return res.status(403).send({status: 403, message: 'seu limit acabou volte amanhã ou compre o premium...'});
    limitAdd(apikey);
var image = await new Cannvas.Welcome()
   .setTextTitle(`${titulo}`)
  .setUsername(`${nome}`)
  .setDiscriminator(`${numero}`)
  .setMemberCount(`${membros}`)
  .setGuildName(`${nomegp}`)
  .setAvatar(`${perfil}`)
  .setColor("border", `#${cor}`)
  .setColor("username-box", `#${cor}`)
  .setColor("discriminator-box", `#${cor}`)
  .setColor("message-box", `#${cor}`)
  .setColor("title", `#${tcor}`)
  .setColor("avatar", `#${cor}`)
  .setColor("Username", `#${lcor}`)
  .setColor("Message", `#${lcor}`)
  .setColor("Discriminator", `#${lcor}`)
  .setColor("Hashtag", `#${lcor}`)    
  .setBackground(`${fundo}`)
  .toAttachment();
  data = image.toBuffer();
  await fs.writeFileSync(bla +'/tmp/bemvindov2.png', data)
  res.sendFile(bla+'/tmp/bemvindov2.png')
   });
   
    router.get('/card/goodbye', async (req, res) => {
    const apikey = req.query.apikey;
    const nome = req.query.nome;    
    const nomegp = req.query.nomegp;    
    const fotogp = req.query.fotogp;    
    const perfil = req.query.perfil;            
    const membros = req.query.membros;
    const fundo = req.query.fundo;        
     if (apikey === undefined || nome === undefined || nomegp === undefined || fotogp === undefined || membros === undefined || fundo === undefined || perfil === undefined) return res.status(404).send({
    status: 404,
    message: `insira o parâmetro apikey & nome & nomegp & fotogp & membros & fundo & perfil`
    });
    const check = await cekKey(apikey);
    if (!check) return res.status(403).send({
    status: 403,
    mensagem: `apikey: ${apikey} não encontrada, por favor registre-se primeiro!`
    });
    let limit = await isLimit(apikey);
    if (limit) return res.status(403).send({status: 403, message: 'seu limit acabou volte amanhã ou compre o premium...'});
    limitAdd(apikey);
var image = await new knights.Goodbye()
    .setUsername(`${nome}`)
    .setGuildName(`${nomegp}`)
    .setGuildIcon(`${fotogp}`)
    .setMemberCount(`${membros}`)
    .setAvatar(`${perfil}`)
    .setBackground(`${fundo}`)
    .toAttachment();
  data = image.toBuffer();
  await fs.writeFileSync(bla +'/tmp/adeus.png', data)
  res.sendFile(bla +'/tmp/adeus.png')
   });
   
   router.get('/card/goodbyev2', async (req, res) => {
    const apikey = req.query.apikey;
    const nome = req.query.nome;    
    const nomegp = req.query.nomegp;    
    const perfil = req.query.perfil;            
    const membros = req.query.membros;
    const titulo = req.query.titulo;        
    const numero = req.query.numero;
    const cor = req.query.cor;
    const lcor = req.query.lcor;
    const tcor = req.query.tcor;
    const fundo = req.query.fundo;
     if (apikey === undefined || nome === undefined || nomegp === undefined || titulo === undefined || membros === undefined || fundo === undefined || perfil === undefined || numero === undefined || cor === undefined || lcor === undefined || tcor === undefined) return res.status(404).send({
    status: 404,
    message: `insira o parâmetro apikey & nome & nomegp & titulo & membros & fundo & perfil & numero & cor & lcor`
    });
    const check = await cekKey(apikey);
    if (!check) return res.status(403).send({
    status: 403,
    mensagem: `apikey: ${apikey} não encontrada, por favor registre-se primeiro!`
    });
    let limit = await isLimit(apikey);
    if (limit) return res.status(403).send({status: 403, message: 'seu limit acabou volte amanhã ou compre o premium...'});
    limitAdd(apikey);
var image = await new Cannvas.Goodbye()
 .setTextTitle(`${titulo}`)
   .setUsername(`${nome}`)
  .setDiscriminator(`${numero}`)
  .setMemberCount(`${membros}`)
  .setGuildName(`${nomegp}`)
  .setAvatar(`${perfil}`)
  .setColor("border", `#${cor}`)
  .setColor("username-box", `#${cor}`)
  .setColor("discriminator-box", `#${cor}`)
  .setColor("message-box", `#${cor}`)
  .setColor("title", `#${tcor}`)
  .setColor("avatar", `#${cor}`)
  .setColor("Username", `#${lcor}`)
  .setColor("Message", `#${lcor}`)
  .setColor("Discriminator", `#${lcor}`)
  .setColor("Hashtag", `#${lcor}`)    
  .setBackground(`${fundo}`)
  .toAttachment();

  data = image.toBuffer();
  await fs.writeFileSync(bla +'/tmp/adeusv2.png', data)
  res.sendFile(bla+'/tmp/adeusv2.png')
   });   
   
   router.get('/card/promote', async (req, res) => {
    const apikey = req.query.apikey;
    const nome = req.query.nome;    
    const nomegp = req.query.nomegp;    
    const fotogp = req.query.fotogp;    
    const perfil = req.query.perfil;            
    const membros = req.query.membros;
    const fundo = req.query.fundo;        
     if (apikey === undefined || nome === undefined || nomegp === undefined || fotogp === undefined || membros === undefined || fundo === undefined || perfil === undefined) return res.status(404).send({
    status: 404,
    message: `insira o parâmetro apikey & nome & nomegp & fotogp & membros & fundo & perfil`
    });
    const check = await cekKey(apikey);
    if (!check) return res.status(403).send({
    status: 403,
    mensagem: `apikey: ${apikey} não encontrada, por favor registre-se primeiro!`
    });
    let limit = await isLimit(apikey);
    if (limit) return res.status(403).send({status: 403, message: 'seu limit acabou volte amanhã ou compre o premium...'});
    limitAdd(apikey);
var image = await new knights.Promote()
    .setUsername(`${nome}`)
    .setGuildName(`${nomegp}`)
    .setGuildIcon(`${fotogp}`)
    .setMemberCount(`${membros}`)
    .setAvatar(`${perfil}`)
    .setBackground(`${fundo}`)
    .toAttachment();
  data = image.toBuffer();
  await fs.writeFileSync(bla +'/tmp/promover.png', data)
  res.sendFile(bla +'/tmp/promover.png')
   });
   
   router.get('/card/demote', async (req, res) => {
    const apikey = req.query.apikey;
    const nome = req.query.nome;    
    const nomegp = req.query.nomegp;    
    const fotogp = req.query.fotogp;    
    const perfil = req.query.perfil;            
    const membros = req.query.membros;
    const fundo = req.query.fundo;        
     if (apikey === undefined || nome === undefined || nomegp === undefined || fotogp === undefined || membros === undefined || fundo === undefined || perfil === undefined) return res.status(404).send({
    status: 404,
    message: `insira o parâmetro apikey & nome & nomegp & fotogp & membros & fundo & perfil`
    });
    const check = await cekKey(apikey);
    if (!check) return res.status(403).send({
    status: 403,
    mensagem: `apikey: ${apikey} não encontrada, por favor registre-se primeiro!`
    });
    let limit = await isLimit(apikey);
    if (limit) return res.status(403).send({status: 403, message: 'seu limit acabou volte amanhã ou compre o premium...'});
    limitAdd(apikey);
var image = await new knights.Demote()
    .setUsername(`${nome}`)
    .setGuildName(`${nomegp}`)
    .setGuildIcon(`${fotogp}`)
    .setMemberCount(`${membros}`)
    .setAvatar(`${perfil}`)
    .setBackground(`${fundo}`)
    .toAttachment();
  data = image.toBuffer();
  await fs.writeFileSync(bla +'/tmp/despromover.png', data)
  res.sendFile(bla +'/tmp/despromover.png')
   });

app.get('/api/runtime', async (req, res, next) => {







try {
const { runtime } = require('./modulos-api/func/runtime.js')
await runtime(apikey).then(e => { 
res.json({ 
status: true, 
criador: `${criador}`,
resultado: e,
})
})
} catch (err) {
res.json({resultado: `${msgerro}`})
};
}) 

app.get('/api/ssweb', async (req, res, next) => {
      var link = req.query.link;
      ;
      





      if(!link)return res.json({status:false, motivo:'Cadê o parâmetro link?'})    
ssweb(link).then((data) => { 
		if (!data) return res.json({erro: `ERROR 404`})
		res.set({'Content-Type': 'image/png'})
		res.send(data) 
		}).catch(e => {
         	res.json({erro:'Erro no Servidor Interno'})
})
})
 

app.get('*', function(req, res) { res.status(404).json({ http_code: 404, aviso: 'PÁGINA NÃO ENCONTRADA!'})})

cron.schedule('0 0 * * *', () => {
const ceemde = JSON.parse(fs.readFileSync('./lib/secret/requests.json'))
ceemde[0].totalreqday = 0
fs.writeFileSync('./lib/secret/requests.json', JSON.stringify(ceemde))
}, {
  scheduled: true,
  timezone: 'America/Sao_Paulo' 
}); 

function fetchApiData() {
  fetch('sua-api-endpoint/metricas')
    .then(response => response.json())
    .then(data => {
      generateMetrics({
        runtime: data.uptime_seconds,
        // Adicione outros dados necessários
      });
      
      // Atualize os dados históricos
      apiHistory.last_30_days = data.history;
    })
    .catch(error => {
      console.error('Erro ao buscar métricas:', error);
    });
}
app.listen(PORT, () => {})
const banner = cfonts.render((`${bannerName}`), {
font: "block",
align: "center",
gradient: ["magenta","red"]
}) 
console.log(banner.string)

console.log(`🔱 𝐏𝐄𝐃𝐑𝐎𝐙𝐙 𝐑𝐄𝐒𝐓 🔱 \n• CONECTADA COM SUCESSO NA PORTA ${PORT}`)

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`ATUALIZANDO SITE.JS DA API`)
process.exit()
})

let file2 = require.resolve('./lib')
fs.watchFile(file2, () => {
fs.unwatchFile(file2)
console.log(`ATUALIZANDO A PASTA "LIB" DA API`)
process.exit()
})

module.exports = router;


